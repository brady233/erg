package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.Locale;
import java.util.function.Supplier;

/**
 * Jutsu ranks from the show, weakest to strongest. Only A and S rank need a minimum player level to learn
 * (the "jutsuRanks" config section); D, C and B can be learned at any level. The rank colors the scroll's name.
 */
public enum JutsuRank {
    D(ChatFormatting.GRAY, Rarity.COMMON, null),
    C(ChatFormatting.GREEN, Rarity.COMMON, null),
    B(ChatFormatting.AQUA, Rarity.UNCOMMON, null),
    A(ChatFormatting.LIGHT_PURPLE, Rarity.RARE, () -> Config.RANK_A_LEVEL),
    S(ChatFormatting.GOLD, Rarity.EPIC, () -> Config.RANK_S_LEVEL);

    private final ChatFormatting color;
    private final Rarity rarity;
    private final Supplier<ForgeConfigSpec.IntValue> level;

    JutsuRank(ChatFormatting color, Rarity rarity, Supplier<ForgeConfigSpec.IntValue> level) {
        this.color = color;
        this.rarity = rarity;
        this.level = level;
    }

    public ChatFormatting color() {
        return color;
    }

    public Rarity rarity() {
        return rarity;
    }

    /** Minimum player level to learn a jutsu of this rank (1 when rank requirements are off). */
    public int requiredLevel() {
        return level != null && Config.b(Config.RANK_REQUIREMENTS) ? Math.max(1, Config.i(level.get())) : 1;
    }

    /** "C-Rank", in the rank's color. */
    public MutableComponent displayName() {
        return Component.translatable("jutsu_rank.shinobiarts." + name().toLowerCase(Locale.ROOT)).withStyle(color);
    }
}
