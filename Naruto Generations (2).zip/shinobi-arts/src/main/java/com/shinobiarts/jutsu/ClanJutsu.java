package com.shinobiarts.jutsu;

import com.shinobiarts.block.TemporaryBlock;
import com.shinobiarts.entity.JutsuProjectile;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Afflictions;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.DojutsuSlot;
import com.shinobiarts.ninja.EightGates;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.registry.ModBlocks;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.util.Scheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static com.shinobiarts.jutsu.JutsuUtil.dmg;

/**
 * The clan releases' jutsu (kekkei genkai), three per clan:
 * <ul>
 *   <li>Wood Release (Senju): Wood Binding, Wood Dome, Deep Forest Emergence</li>
 *   <li>Ice Release (Yuki): Ice Needles, Ice Prison, Demonic Ice Mirrors</li>
 *   <li>Magnet Release (Kazekage): Iron Sand Drizzle, Iron Sand Coffin, Iron Sand World Method</li>
 *   <li>Bone (Kaguya, Dead Bone Pulse): Finger Bone Bullets, Dance of the Willow, Dance of the Seedling Fern</li>
 *   <li>Sealing (Uzumaki): Barrier, Adamantine Sealing Chains, Five Elements Seal</li>
 * </ul>
 * Whoever has the kekkei genkai (the clan once it's locked in, or anyone from DNA or a scroll) gets the release and
 * all three jutsu (see KekkeiGenkai). Damage is worked out when the jutsu is cast (so upgrades and charging count) and dealt by
 * {@link Scheduler} tasks for the parts that play out over time. Blocks they raise are {@link TemporaryBlock}s.
 */
public final class ClanJutsu {
    private static final BlockParticleOption WOOD = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.OAK_LOG.defaultBlockState());
    private static final BlockParticleOption LEAVES = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.OAK_LEAVES.defaultBlockState());
    private static final BlockParticleOption ICE = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.PACKED_ICE.defaultBlockState());
    private static final BlockParticleOption SAND = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.BLACK_CONCRETE_POWDER.defaultBlockState());
    private static final BlockParticleOption BONE = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.BONE_BLOCK.defaultBlockState());
    private static final DustParticleOptions ICE_DUST = new DustParticleOptions(new Vector3f(0.75f, 0.92f, 1.0f), 1.1f);
    private static final DustParticleOptions IRON_DUST = new DustParticleOptions(new Vector3f(0.12f, 0.12f, 0.16f), 1.4f);
    private static final DustParticleOptions BONE_DUST = new DustParticleOptions(new Vector3f(0.95f, 0.92f, 0.82f), 1.2f);
    private static final DustParticleOptions CHAIN_DUST = new DustParticleOptions(new Vector3f(1.0f, 0.82f, 0.35f), 1.0f);
    private static final DustParticleOptions SEAL_DUST = new DustParticleOptions(new Vector3f(0.95f, 0.3f, 0.45f), 1.0f);

    private ClanJutsu() {}

    private static void noTarget(ServerPlayer p) {
        p.displayClientMessage(Component.translatable("message.shinobiarts.no_target").withStyle(ChatFormatting.GRAY), true);
    }

    private static void noRoom(ServerPlayer p) {
        p.displayClientMessage(Component.translatable("message.shinobiarts.no_room").withStyle(ChatFormatting.GRAY), true);
    }

    /** The empty spot just above the ground near {@code start} (searching 3 blocks up and 5 down), or null. */
    @Nullable
    private static BlockPos ground(ServerLevel level, BlockPos start) {
        BlockPos pos = start.above(3);
        for (int i = 0; i < 9; i++, pos = pos.below()) {
            BlockPos below = pos.below();
            if (level.getBlockState(pos).canBeReplaced() && level.getBlockState(pos).getFluidState().isEmpty()
                    && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
                return pos;
            }
        }
        return null;
    }

    /** Builds a shell of {@code state} around a creature (its sides and over its head), leaving it inside. */
    private static int encase(ServerLevel level, LivingEntity target, BlockState state, int ticks, boolean plants) {
        AABB box = target.getBoundingBox();
        int x0 = Mth.floor(box.minX) - 1, x1 = Mth.floor(box.maxX - 1e-3) + 1;
        int y0 = Mth.floor(box.minY), y1 = Mth.floor(box.maxY - 1e-3) + 1;
        int z0 = Mth.floor(box.minZ) - 1, z1 = Mth.floor(box.maxZ - 1e-3) + 1;
        int placed = 0;
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (new AABB(pos).intersects(box)) continue;
                    if (TemporaryBlock.place(level, pos, state, ticks, plants)) placed++;
                }
            }
        }
        return placed;
    }

    /** Spirals {@code particle} up around a creature over half a second (roots, chains...). */
    private static void coil(ServerLevel level, LivingEntity target, net.minecraft.core.particles.ParticleOptions particle, int strands) {
        double r = target.getBbWidth() * 0.75 + 0.3;
        Scheduler.repeat(0, 2, 10, i -> {
            if (!target.isAlive()) return;
            Vec3 base = target.position();
            double y = target.getBbHeight() * (i / 9.0);
            for (int k = 0; k < strands; k++) {
                double a = i * 0.9 + k * Math.PI * 2 / strands;
                level.sendParticles(particle, base.x + Math.cos(a) * r, base.y + y, base.z + Math.sin(a) * r, 3, 0.05, 0.05, 0.05, 0);
            }
        });
    }

    // ================================================================ WOOD RELEASE (Senju)

    /** Wood Binding: roots race across the ground and coil around the target, holding it fast for 4 seconds. */
    public static boolean woodBinding(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 24);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        target.hurt(ModDamage.jutsu(level, p, p), dmg(6f));
        Afflictions.stun(target, 80, Afflictions.STUN_NONE);
        // a root races over the ground and beams of wood coil up round the target
        com.shinobiarts.fx.Fx.send(level, com.shinobiarts.fx.Fx.Visual.WOOD_BIND, p.position(), target.position(), target.getId(), -1, 1f, 80);
        JutsuUtil.line(level, WOOD, p.position().add(0, 0.15, 0), target.position().add(0, 0.15, 0), 1.2, 1, 0.12);
        JutsuUtil.sound(level, target.position(), SoundEvents.ROOTED_DIRT_BREAK, 1.5f, 0.6f);
        JutsuUtil.sound(level, target.position(), SoundEvents.WOOD_BREAK, 1.2f, 0.5f);
        return true;
    }

    /** Wood Dome: a dome of wood grows up around you, keeping out attacks and projectiles for 10 seconds. */
    public static boolean woodDome(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        BlockState wood = ModBlocks.WOOD_WALL.get().defaultBlockState();
        BlockPos c = p.blockPosition();
        boolean plants = JutsuUtil.griefing(level, p);
        int placed = 0;
        for (int dy = 0; dy <= 3; dy++) {
            java.util.List<BlockPos> layer = new java.util.ArrayList<>();
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (dist < 2.5 || dist >= 3.5) continue;
                    layer.add(c.offset(dx, dy, dz));
                }
            }
            if (dy == 0) {                                   // the first ring now (it tells whether there's room)
                for (BlockPos pos : layer) {
                    if (!TemporaryBlock.place(level, pos, wood, 200, plants)) continue;
                    placed++;
                    level.sendParticles(WOOD, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 4, 0.3, 0.3, 0.3, 0.05);
                }
            } else {                                         // then it closes over, a ring at a time
                int delay = dy * 3;
                Scheduler.later(delay, () -> {
                    for (BlockPos pos : layer) {
                        if (TemporaryBlock.place(level, pos, wood, 200 - delay, plants)) {
                            level.sendParticles(WOOD, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 4, 0.3, 0.3, 0.3, 0.05);
                        }
                    }
                    JutsuUtil.sound(level, Vec3.atCenterOf(c), SoundEvents.WOOD_PLACE, 1.2f, 0.6f);
                });
                placed += layer.size();
            }
        }
        if (placed == 0) {
            noRoom(p);
            return false;
        }
        JutsuUtil.sound(level, p.position(), SoundEvents.WOOD_PLACE, 1.5f, 0.5f);
        JutsuUtil.sound(level, p.position(), SoundEvents.ROOTED_DIRT_PLACE, 1.5f, 0.6f);
        return true;
    }

    /**
     * Deep Forest Emergence: a forest bursts out of the ground where you look (9 x 9 blocks). The trees strike
     * everything there as they rise, then their roots and branches keep seizing and crushing whoever stays, for 20 s.
     */
    public static boolean deepForest(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 24);
        Vec3 c = hit.getType() == HitResult.Type.MISS ? p.position() : hit.getLocation();
        BlockPos center = BlockPos.containing(c);
        BlockState wood = ModBlocks.WOOD_WALL.get().defaultBlockState();
        boolean plants = JutsuUtil.griefing(level, p);
        RandomSource r = level.getRandom();
        float burst = dmg(10f), squeeze = dmg(1.5f);

        // somewhere for the trees to grow from
        int trunks = 0;
        for (int i = 0; i < 6; i++) if (ground(level, center.offset(r.nextInt(9) - 4, 0, r.nextInt(9) - 4)) != null) trunks++;
        if (trunks == 0) {
            noRoom(p);
            return false;
        }
        // twisting trunks with branches and leaves burst up over the area, and sink back after 20 s
        com.shinobiarts.fx.Fx.at(level, com.shinobiarts.fx.Fx.Visual.FOREST, c, 1f, 400);
        level.sendParticles(WOOD, c.x, c.y + 0.5, c.z, 60, 3.0, 0.5, 3.0, 0.15);
        for (LivingEntity e : JutsuUtil.inRadius(level, p, c, 5.5)) {
            e.hurt(ModDamage.jutsu(level, null, p), burst);
            JutsuUtil.push(e, new Vec3(0, 0.35, 0)); // with the hit's knockback: thrown about 3 blocks up
        }
        Scheduler.repeat(20, 20, 20, i -> {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c, 5.5)) {
                e.hurt(ModDamage.jutsu(level, null, p), squeeze);
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 25, 4));
                Vec3 in = c.subtract(e.position()).multiply(1, 0, 1);
                if (in.lengthSqr() > 1) JutsuUtil.push(e, in.normalize().scale(0.25)); // dragged in by the roots
                level.sendParticles(WOOD, e.getX(), e.getY() + 0.3, e.getZ(), 10, 0.4, 0.3, 0.4, 0.05);
            }
            if (i % 3 == 0) {
                level.sendParticles(LEAVES, c.x, c.y + 3, c.z, 30, 3.5, 1.0, 3.5, 0.02);
                JutsuUtil.sound(level, c, SoundEvents.ROOTED_DIRT_BREAK, 1.0f, 0.5f);
            }
        });
        JutsuUtil.sound(level, c, SoundEvents.WOOD_BREAK, 2.0f, 0.4f);
        JutsuUtil.sound(level, c, SoundEvents.ROOTED_DIRT_PLACE, 2.0f, 0.5f);
        JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 0.6f, 0.6f);
        return true;
    }

    // ================================================================ ICE RELEASE (Yuki)

    /** Ice Needles: a fan of eight needles of ice. Each one stings, slows and chills. */
    public static boolean iceNeedles(ServerPlayer p, NinjaData d) {
        float each = dmg(2f);
        for (int i = 0; i < 8; i++) JutsuProjectile.shoot(p, JutsuProjectile.Kind.ICE_NEEDLE, 2.6f, -14f + i * 4f, each);
        JutsuUtil.particles(p.serverLevel(), ParticleTypes.SNOWFLAKE, p.getEyePosition().add(p.getLookAngle()), 12, 0.3, 0.05);
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.AMETHYST_CLUSTER_BREAK, 1.0f, 1.6f);
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.PLAYER_HURT_FREEZE, 0.6f, 1.5f);
        return true;
    }

    /** Ice Prison: freezes the target solid inside a block of ice for 3 seconds. */
    public static boolean icePrison(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 20);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        target.hurt(ModDamage.jutsu(level, p, p), dmg(5f));
        Afflictions.stun(target, 60, Afflictions.STUN_NONE);
        target.clearFire();
        target.setTicksFrozen(Math.max(target.getTicksFrozen(), target.getTicksRequiredToFreeze() + 120));
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.ICE_PRISON, target, null, 1f, 60);
        Scheduler.later(60, () -> {                          // the crystal shatters
            Vec3 at = target.position();
            com.shinobiarts.fx.Fx.at(level, com.shinobiarts.fx.Fx.Visual.ICE_SHATTER, at, target.getBbHeight(), 2);
            level.sendParticles(ICE, at.x, at.y + target.getBbHeight() / 2, at.z, 40, 0.6, 0.8, 0.6, 0.15);
            JutsuUtil.sound(level, at, SoundEvents.GLASS_BREAK, 1.5f, 0.7f);
        });
        Vec3 mid = target.getBoundingBox().getCenter();
        JutsuUtil.particles(level, ICE, mid, 40, target.getBbWidth() * 0.8, 0.1);
        JutsuUtil.particles(level, ParticleTypes.SNOWFLAKE, mid, 30, target.getBbWidth(), 0.05);
        JutsuUtil.sound(level, mid, SoundEvents.GLASS_PLACE, 1.5f, 0.6f);
        JutsuUtil.sound(level, mid, SoundEvents.POWDER_SNOW_PLACE, 1.5f, 0.5f);
        return true;
    }

    /**
     * Demonic Ice Mirrors: a ring of ice mirrors closes around the target. For 6 seconds needles fly at it from the
     * mirrors, one after another, while it stays inside the ring (or until it breaks out).
     */
    public static boolean iceMirrors(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 20);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        Vec3 c = target.position();
        // a dome of ice mirrors (twelve standing, eight tipped in above them)
        com.shinobiarts.fx.Fx.send(level, com.shinobiarts.fx.Fx.Visual.ICE_MIRRORS, c, c, -1, p.getId(), 1f, 130);
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 1));
        float each = dmg(1.5f);
        RandomSource r = level.getRandom();
        Scheduler.repeat(10, 8, 15, i -> {
            if (!target.isAlive() || target.position().distanceToSqr(c) > 25) return;
            double a = r.nextDouble() * Math.PI * 2;
            Vec3 from = c.add(Math.cos(a) * 3.0, 1.2 + r.nextDouble(), Math.sin(a) * 3.0);
            Vec3 to = target.getBoundingBox().getCenter();
            com.shinobiarts.fx.Fx.line(level, com.shinobiarts.fx.Fx.Visual.ICE_NEEDLE_FLY, from, to, 1f, 4);
            level.sendParticles(ParticleTypes.SNOWFLAKE, to.x, to.y, to.z, 4, 0.2, 0.2, 0.2, 0.02);
            target.invulnerableTime = 0;
            target.hurt(ModDamage.jutsu(level, null, p), each);
            JutsuUtil.sound(level, to, SoundEvents.GLASS_HIT, 1.0f, 1.6f);
        });
        JutsuUtil.particles(level, ParticleTypes.SNOWFLAKE, c.add(0, 1.5, 0), 60, 3.0, 0.05);
        JutsuUtil.sound(level, c, SoundEvents.GLASS_PLACE, 1.8f, 0.5f);
        JutsuUtil.sound(level, c, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.5f, 0.8f);
        return true;
    }

    // ================================================================ MAGNET RELEASE (Kazekage)

    /** The creature you're looking at, or else the block, or null if there's nothing within {@code range}. */
    @Nullable
    private static Vec3 aimPoint(ServerPlayer p, double range) {
        LivingEntity target = JutsuUtil.rayTarget(p, range);
        if (target != null) return target.position();
        BlockHitResult hit = JutsuUtil.rayBlock(p, range);
        return hit.getType() == HitResult.Type.MISS ? null : hit.getLocation();
    }

    /** Iron Sand Drizzle: iron sand gathers overhead and rains down in hard pellets where you look. */
    public static boolean ironSandDrizzle(ServerPlayer p, NinjaData d) {
        Vec3 aimed = aimPoint(p, 24);
        final Vec3 c = aimed != null ? aimed : JutsuUtil.aimAnywhere(p, 24);
        ServerLevel level = p.serverLevel();
        float each = dmg(1.5f);
        com.shinobiarts.fx.Fx.at(level, com.shinobiarts.fx.Fx.Visual.IRON_RAIN, c, 1f, 32);
        Scheduler.repeat(4, 3, 8, i -> {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c.add(0, 1, 0), 3)) {
                e.invulnerableTime = 0;
                e.hurt(ModDamage.jutsu(level, null, p), each);
            }
            if (i % 2 == 0) JutsuUtil.sound(level, c, SoundEvents.SAND_HIT, 1.2f, 0.7f);
        });
        JutsuUtil.sound(level, p.position(), SoundEvents.SAND_PLACE, 1.2f, 0.5f);
        return true;
    }

    /** Iron Sand Coffin: iron sand swallows the target, then crushes it shut a moment later. */
    public static boolean ironSandCoffin(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 20);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        float crush = dmg(16f);
        Afflictions.stun(target, 30, Afflictions.STUN_NONE);
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.IRON_COFFIN, target, null, 1f, 34);
        JutsuUtil.sound(level, target.position(), SoundEvents.SAND_PLACE, 1.5f, 0.5f);
        Scheduler.later(30, () -> {
            if (!target.isAlive()) return;
            Vec3 mid = target.getBoundingBox().getCenter();
            target.invulnerableTime = 0;
            target.hurt(ModDamage.jutsu(level, null, p), crush);
            level.sendParticles(SAND, mid.x, mid.y, mid.z, 50, 0.6, 0.8, 0.6, 0.15);
            level.sendParticles(IRON_DUST, mid.x, mid.y, mid.z, 40, 0.8, 0.8, 0.8, 0.0);
            JutsuUtil.sound(level, mid, SoundEvents.SAND_BREAK, 2.0f, 0.4f);
            JutsuUtil.sound(level, mid, SoundEvents.GENERIC_EXPLODE, 0.5f, 1.4f);
        });
        return true;
    }

    /** Iron Sand World Method: a mass of iron sand forms in front of you and bursts into spikes in every direction. */
    public static boolean ironSandWorld(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 c = p.getEyePosition().add(p.getLookAngle().scale(4));
        float hit = dmg(16f);
        com.shinobiarts.fx.Fx.at(level, com.shinobiarts.fx.Fx.Visual.IRON_WORLD, c, 1f, 50);   // the sphere, then the spikes
        Scheduler.later(12, () -> {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c, 8)) {
                e.hurt(ModDamage.jutsu(level, null, p), hit);
                Vec3 away = e.position().subtract(c);
                away = away.lengthSqr() < 1e-4 ? new Vec3(0, 1, 0) : away.normalize();
                JutsuUtil.push(e, away.scale(0.3).add(0, 0.15, 0)); // with the hit's knockback: thrown about 5 blocks
            }
            JutsuUtil.sound(level, c, SoundEvents.SAND_BREAK, 2.0f, 0.4f);
            JutsuUtil.sound(level, c, SoundEvents.TRIDENT_RIPTIDE_3, 1.2f, 0.6f);
        });
        JutsuUtil.sound(level, c, SoundEvents.SAND_PLACE, 1.5f, 0.4f);
        return true;
    }

    // ================================================================ BONE (Kaguya: Dead Bone Pulse)

    /** Finger Bone Bullets: fire the bones of your fingertips, five in a row, wherever you're aiming. */
    public static boolean fingerBullets(ServerPlayer p, NinjaData d) {
        float each = dmg(3.5f);
        Scheduler.repeat(0, 3, 5, i -> {
            if (!p.isAlive()) return;
            JutsuProjectile.shoot(p, JutsuProjectile.Kind.BONE_BULLET, 3.0f, 0f, each);
            JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.BONE_BLOCK_HIT, 1.0f, 1.6f);
        });
        return true;
    }

    /** Dance of the Willow: bones jut from your arms and body like blades and armor (stronger hits, less damage taken) for 20 s. */
    public static boolean willowDance(ServerPlayer p, NinjaData d) {
        d.setBoneArmorUntil(p.level().getGameTime() + 400);             // the bone blades everyone sees
        SharinganManager.updateLook(p);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 1));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 400, 0));
        JutsuUtil.particles(p.serverLevel(), BONE, p.position().add(0, 1, 0), 50, 0.5, 0.1);
        JutsuUtil.particles(p.serverLevel(), BONE_DUST, p.position().add(0, 1, 0), 30, 0.6, 0.0);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.BONE_BLOCK_PLACE, 1.5f, 0.6f);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.SKELETON_HURT, 0.8f, 0.5f);
        return true;
    }

    /**
     * Dance of the Seedling Fern: a forest of huge bone spikes erupts from the ground around you in waves, out to
     * 9 blocks. Everything it catches is impaled and thrown up (once each); the spikes stay for 8 seconds.
     */
    public static boolean seedlingFern(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 c = p.position();
        BlockPos center = p.blockPosition();
        BlockState bone = ModBlocks.BONE_SPIKE.get().defaultBlockState();
        boolean plants = JutsuUtil.griefing(level, p);
        float hit = dmg(14f);
        Set<UUID> struck = new HashSet<>();
        com.shinobiarts.fx.Fx.at(level, com.shinobiarts.fx.Fx.Visual.BONE_FOREST, c, 1f, 170);   // the spikes themselves
        for (int w = 0; w < 4; w++) {
            int wave = w;
            Scheduler.later(w * 3, () -> {
                double inner = 1.5 + wave * 2, outer = inner + 2;
                level.sendParticles(BONE, c.x, c.y + 0.3, c.z, 20 + wave * 10, outer * 0.6, 0.2, outer * 0.6, 0.1);
                for (LivingEntity e : JutsuUtil.inRadius(level, p, c, outer)) {
                    if (e.position().distanceTo(c) < inner - 0.5 || !struck.add(e.getUUID())) continue;
                    e.hurt(ModDamage.jutsu(level, null, p), hit);
                    JutsuUtil.push(e, new Vec3(0, 0.5, 0)); // with the hit's knockback: thrown about 4 blocks up
                    level.sendParticles(BONE_DUST, e.getX(), e.getY() + 1, e.getZ(), 15, 0.3, 0.5, 0.3, 0.0);
                }
                JutsuUtil.sound(level, c, SoundEvents.BONE_BLOCK_BREAK, 2.0f, 0.5f + wave * 0.1f);
            });
        }
        JutsuUtil.sound(level, c, SoundEvents.SKELETON_AMBIENT, 1.0f, 0.4f);
        return true;
    }

    // ================================================================ SEALING (Uzumaki)

    /**
     * Barrier: a sealing barrier surrounds you for 8 seconds (4 blocks across). Arrows, thrown weapons and projectile
     * jutsu are stopped at its edge, and creatures that come at you are pushed back out.
     */
    public static boolean barrier(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.BARRIER, p, null, 3.5f, 160);
        Scheduler.repeat(0, 2, 80, i -> {
            if (!p.isAlive() || p.isRemoved() || p.level() != level) return;
            Vec3 c = p.position();
            for (Projectile proj : level.getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(4),
                    pr -> pr.getOwner() != p && pr.position().distanceToSqr(c.add(0, 1, 0)) < 16)) {
                level.sendParticles(SEAL_DUST, proj.getX(), proj.getY(), proj.getZ(), 8, 0.15, 0.15, 0.15, 0.0);
                proj.discard();
            }
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c.add(0, 1, 0), 3.5)) {
                if (e instanceof Player other && !other.canHarmPlayer(p)) continue;
                Vec3 out = e.position().subtract(c).multiply(1, 0, 1);
                out = out.lengthSqr() < 1e-4 ? new Vec3(1, 0, 0) : out.normalize();
                JutsuUtil.push(e, out.scale(0.7).add(0, 0.15, 0));
            }
            if (i % 4 == 0) level.sendParticles(ParticleTypes.ENCHANT, c.x, c.y + 1.5, c.z, 10, 2.0, 1.2, 2.0, 0.2);
        });
        JutsuUtil.sound(level, p.position(), SoundEvents.BEACON_ACTIVATE, 1.0f, 1.5f);
        JutsuUtil.sound(level, p.position(), SoundEvents.ENCHANTMENT_TABLE_USE, 1.0f, 0.8f);
        return true;
    }

    /**
     * Adamantine Sealing Chains: chakra chains shoot out and bind the target for 4 seconds. A ninja loses 30% of
     * their chakra; a creature is left weakened.
     */
    public static boolean adamantineChains(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 24);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        target.hurt(ModDamage.jutsu(level, p, p), dmg(3f));
        Afflictions.stun(target, 80, Afflictions.STUN_NONE);
        if (target instanceof ServerPlayer victim) {
            NinjaData vd = NinjaData.get(victim);
            if (vd != null) {
                vd.consumeChakra(vd.maxChakra() * 0.30f);
                ModNetwork.sync(victim);
            }
        } else {
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 1));
        }
        // golden chains burst from your back, arc over and wrap the target
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.CHAINS, p, target, 1f, 80);
        JutsuUtil.sound(level, target.position(), SoundEvents.CHAIN_PLACE, 1.5f, 0.6f);
        JutsuUtil.sound(level, p.position(), SoundEvents.CHAIN_HIT, 1.5f, 0.8f);
        return true;
    }

    /**
     * Five Elements Seal: five burning fingertips strike the target up close (5 blocks) and seal its chakra for
     * 10 seconds: no jutsu, eye techniques or Eight Gates. A ninja's eyes switch off and open gates close.
     */
    public static boolean fiveElementsSeal(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 5);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        target.hurt(ModDamage.jutsu(level, p, p), dmg(4f));
        Afflictions.seal(target, 200);
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.FIVE_SEAL, target, p, 1f, 200);   // the seal on its stomach
        if (target instanceof ServerPlayer victim) {
            NinjaData vd = NinjaData.get(victim);
            if (vd != null) {
                eyesOff(victim, vd);
                if (vd.getGatesOpen() > 0) EightGates.close(victim, vd, false);
                ModNetwork.sync(victim);
            }
        } else {
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 0));
        }
        Vec3 mid = target.getBoundingBox().getCenter();
        for (int k = 0; k < 5; k++) { // the five flames
            double a = k * Math.PI * 2 / 5;
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, mid.x + Math.cos(a) * 0.45, mid.y + 0.1, mid.z + Math.sin(a) * 0.45, 6, 0.03, 0.08, 0.03, 0.01);
        }
        level.sendParticles(SEAL_DUST, mid.x, mid.y, mid.z, 30, 0.4, 0.5, 0.4, 0.0);
        level.sendParticles(ParticleTypes.ENCHANT, mid.x, mid.y, mid.z, 40, 0.5, 0.6, 0.5, 0.5);
        JutsuUtil.sound(level, mid, SoundEvents.BEACON_DEACTIVATE, 1.5f, 0.8f);
        JutsuUtil.sound(level, mid, SoundEvents.EVOKER_CAST_SPELL, 1.0f, 1.2f);
        return true;
    }

    /** Switches a ninja's eyes off (sealed chakra can't keep them on). */
    private static void eyesOff(ServerPlayer p, NinjaData d) {
        Dojutsu eyes = d.getActiveDojutsu();
        if (eyes == Dojutsu.NONE) return;
        if (eyes == Dojutsu.BYAKUGAN) p.removeEffect(MobEffects.NIGHT_VISION);
        d.setActiveDojutsu(Dojutsu.NONE);
        p.displayClientMessage(Component.translatable("message.shinobiarts.dojutsu_off", d.dojutsuName(eyes)), true);
        DojutsuSlot.sync(p);
        SharinganManager.broadcastEyes(p);
    }
}
