package com.shinobiarts.combat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;

/**
 * /vault: a personal 54-slot storage (a double chest). It's saved with the player in the part of their data that
 * Forge carries over on death, so vault items are never dropped or lost when you die. Every change is saved at once.
 */
public final class Vault {
    public static final int SIZE = 54;
    private static final String KEY = "shinobiarts_vault";

    private Vault() {}

    public static void open(ServerPlayer player) {
        SimpleContainer container = new SimpleContainer(SIZE);
        load(player, container);
        container.addListener(changed -> save(player, container));
        player.openMenu(new SimpleMenuProvider((id, inventory, p) -> ChestMenu.sixRows(id, inventory, container),
                Component.translatable("container.shinobiarts.vault")));
    }

    private static CompoundTag persisted(Player player) {
        CompoundTag root = player.getPersistentData();
        if (!root.contains(Player.PERSISTED_NBT_TAG, Tag.TAG_COMPOUND)) root.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        return root.getCompound(Player.PERSISTED_NBT_TAG);
    }

    private static void load(Player player, SimpleContainer container) {
        ListTag list = persisted(player).getList(KEY, Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            int slot = entry.getByte("Slot") & 255;
            if (slot < SIZE) container.setItem(slot, ItemStack.of(entry));
        }
    }

    private static void save(Player player, SimpleContainer container) {
        ListTag list = new ListTag();
        for (int i = 0; i < SIZE; i++) {
            ItemStack stack = container.getItem(i);
            if (stack.isEmpty()) continue;
            CompoundTag entry = new CompoundTag();
            entry.putByte("Slot", (byte) i);
            stack.save(entry);
            list.add(entry);
        }
        persisted(player).put(KEY, list);
    }
}
