package com.shinobiarts.quest;

import com.shinobiarts.Config;
import com.shinobiarts.network.BoardActionPacket;
import com.shinobiarts.network.BoardPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.Rank;
import com.shinobiarts.registry.ModItems;
import com.shinobiarts.village.VillageData;
import com.shinobiarts.village.VillageManager;
import com.shinobiarts.village.Villages;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * The village quest board (server side): builds what the board screen shows and carries out its buttons.
 * Players see their own random quests (hourly, daily, weekly, monthly) and the quests their Kage posted.
 * Quests must be accepted; kill/catch quests count up as you play, gather quests complete once you carry the
 * items, and "Claim" hands the items in and pays the reward (EXP bottles and Ryo). Every handed-in item goes to
 * the village storage. The Kage menu posts and removes village quests, promotes members, appoints Advisors and
 * opens the village storage.
 */
public final class QuestBoard {
    private QuestBoard() {}

    /** "Defeat 5 Ninja Bandits", "Bring 16 Logs". */
    public static MutableComponent title(QuestType type, int count, String target) {
        if (type == QuestType.GATHER) {
            Component what = target.startsWith("#")
                    ? Component.translatable("quest.shinobiarts.target." + target.substring(target.indexOf(':') + 1))
                    : QuestItems.icon(target).getDescription();
            return Component.translatable("quest.shinobiarts.gather", count, what);
        }
        return Component.translatable("quest.shinobiarts." + type.id(), count);
    }

    // ---------------------------------------------------------------- opening

    /** Opens (or refreshes) the board for a player; {@code admin} opens the Kage menu. */
    public static void open(ServerPlayer player, boolean admin) {
        VillageManager.refresh(player);
        NinjaData d = NinjaData.get(player);
        if (d == null || d.getVillage().isEmpty()) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.no_village").withStyle(ChatFormatting.RED));
            return;
        }
        if (admin && !d.isKage()) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.not_kage", Villages.name(d.getVillage())).withStyle(ChatFormatting.RED));
            return;
        }
        PlayerQuests quests = PlayerQuests.of(player);
        quests.checkGather();
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new BoardPacket(build(player, d, quests, admin)));
    }

    private static CompoundTag build(ServerPlayer player, NinjaData d, PlayerQuests quests, boolean admin) {
        CompoundTag tag = new CompoundTag();
        tag.putString("Screen", admin ? "kage" : "board");
        tag.putString("Village", Villages.name(d.getVillage()));
        tag.putBoolean("Kage", d.isKage());
        LocalDateTime now = LocalDateTime.now();
        for (QuestPeriod period : QuestPeriod.values()) {
            ListTag list = new ListTag();
            List<PlayerQuests.Entry> entries = quests.quests(period);
            for (int i = 0; i < entries.size(); i++) {
                PlayerQuests.Entry e = entries.get(i);
                QuestDefs.QuestDef def = QuestDefs.byId(e.id);
                if (def == null) continue;
                int progress = def.type() == QuestType.GATHER && e.status == PlayerQuests.ACCEPTED
                        ? Math.min(def.count(), QuestItems.count(player.getInventory(), def.target())) : e.progress;
                CompoundTag row = row("p:" + period.id() + ":" + i, title(def.type(), def.count(), def.target()), def.type() == QuestType.GATHER
                        ? def.target() : "", def.count(), progress, e.status, def.bottles(), def.ryo(), "");
                com.shinobiarts.jutsu.Jutsu scroll = e.scroll.isEmpty() ? null : com.shinobiarts.jutsu.Jutsus.get(e.scroll);
                if (scroll != null) {
                    row.putString("Scroll", Component.Serializer.toJson(scroll.displayName()));
                    row.putInt("ScrollRank", scroll.rank().ordinal());
                }
                list.add(row);
            }
            tag.put(period.id(), list);
            tag.putLong(period.id() + "Reset", period.secondsUntilReset(now));
        }
        ListTag kage = new ListTag();
        for (VillageData.KageQuest q : VillageData.get(player.server).quests(d.getVillage())) {
            int status = quests.kageStatus(d.getVillage(), q.id);
            int have = Math.min(q.count, QuestItems.count(player.getInventory(), q.item));
            if (status == PlayerQuests.ACCEPTED && have >= q.count) status = PlayerQuests.COMPLETE;
            if (status == PlayerQuests.COMPLETE && have < q.count) status = PlayerQuests.ACCEPTED;
            kage.add(row("k:" + q.id, title(QuestType.GATHER, q.count, q.item), q.item, q.count, have, status, q.bottles, q.ryo, q.postedBy));
        }
        tag.put("kage", kage);
        // the village's Advisors, online ones first: who players can ask for help
        ListTag advisors = new ListTag();
        for (boolean online : new boolean[]{true, false}) {
            VillageData.get(player.server).advisors(d.getVillage()).forEach((id, name) -> {
                if ((player.server.getPlayerList().getPlayer(id) != null) != online) return;
                CompoundTag a = new CompoundTag();
                a.putString("Name", name);
                a.putBoolean("Online", online);
                advisors.add(a);
            });
        }
        tag.put("advisors", advisors);
        if (admin) {
            ListTag members = new ListTag();
            for (ServerPlayer p : player.server.getPlayerList().getPlayers()) {
                NinjaData pd = NinjaData.get(p);
                if (pd == null || !d.getVillage().equals(pd.getVillage())) continue;
                CompoundTag m = new CompoundTag();
                m.putString("Name", p.getGameProfile().getName());
                m.putString("Rank", pd.getRank().displayName().getString());
                m.putInt("Level", pd.getLevel());
                m.putBoolean("Kage", pd.isKage());
                m.putBoolean("Advisor", pd.isAdvisor());
                members.add(m);
            }
            tag.put("members", members);
            tag.putInt("MaxBottles", Config.i(Config.KAGE_MAX_BOTTLES));
            tag.putLong("PostWait", (VillageData.get(player.server).postCooldownLeft(d.getVillage(), System.currentTimeMillis()) + 999) / 1000);
            tag.putInt("MaxRyo", Config.i(Config.KAGE_MAX_RYO));
        }
        return tag;
    }

    private static CompoundTag row(String uid, Component title, String item, int count, int progress, int status, int bottles, long ryo, String by) {
        CompoundTag r = new CompoundTag();
        r.putString("Uid", uid);
        r.putString("Title", Component.Serializer.toJson(title));
        r.putString("Item", item);
        r.putInt("Count", count);
        r.putInt("Progress", progress);
        r.putInt("Status", status);
        r.putInt("Bottles", bottles);
        r.putLong("Ryo", ryo);
        r.putString("By", by);
        return r;
    }

    // ---------------------------------------------------------------- buttons

    public static void handle(ServerPlayer player, BoardActionPacket packet) {
        NinjaData d = NinjaData.get(player);
        if (d == null || d.getVillage().isEmpty()) return;
        boolean admin = false;
        switch (packet.action()) {
            case BoardActionPacket.ACCEPT -> setStatus(player, d, packet.text(), PlayerQuests.ACCEPTED);
            case BoardActionPacket.DECLINE -> setStatus(player, d, packet.text(), PlayerQuests.DECLINED);
            case BoardActionPacket.CLAIM -> claim(player, d, packet.text());
            case BoardActionPacket.POST -> {
                admin = true;
                post(player, d, packet.a(), packet.b(), packet.c());
            }
            case BoardActionPacket.REMOVE -> {
                admin = true;
                if (d.isKage()) VillageData.get(player.server).remove(d.getVillage(), packet.a());
            }
            case BoardActionPacket.PROMOTE -> {
                admin = true;
                promote(player, d, packet.text(), packet.a());
            }
            case BoardActionPacket.ADVISOR -> {
                admin = true;
                toggleAdvisor(player, d, packet.text());
            }
            case BoardActionPacket.STORAGE -> {
                openStorage(player, d);
                return;
            }
            case BoardActionPacket.OPEN_KAGE -> admin = true;
            default -> {
            }
        }
        open(player, admin);
    }

    private static void setStatus(ServerPlayer player, NinjaData d, String uid, int status) {
        PlayerQuests quests = PlayerQuests.of(player);
        if (uid.startsWith("p:")) {
            String[] parts = uid.split(":");
            if (parts.length != 3) return;
            for (QuestPeriod period : QuestPeriod.values()) {
                if (!period.id().equals(parts[1])) continue;
                List<PlayerQuests.Entry> entries = quests.quests(period);
                int i = parseInt(parts[2]);
                if (i < 0 || i >= entries.size() || entries.get(i).status != PlayerQuests.OFFERED) return;
                entries.get(i).status = status;
                quests.setQuests(period, entries);
            }
        } else if (uid.startsWith("k:")) {
            int id = parseInt(uid.substring(2));
            if (VillageData.get(player.server).quest(d.getVillage(), id) == null) return;
            if (quests.kageStatus(d.getVillage(), id) != PlayerQuests.OFFERED) return;
            quests.setKageStatus(d.getVillage(), id, status);
        }
        if (status == PlayerQuests.ACCEPTED) quests.checkGather();
    }

    private static void claim(ServerPlayer player, NinjaData d, String uid) {
        PlayerQuests quests = PlayerQuests.of(player);
        if (uid.startsWith("p:")) {
            String[] parts = uid.split(":");
            if (parts.length != 3) return;
            for (QuestPeriod period : QuestPeriod.values()) {
                if (!period.id().equals(parts[1])) continue;
                List<PlayerQuests.Entry> entries = quests.quests(period);
                int i = parseInt(parts[2]);
                if (i < 0 || i >= entries.size()) return;
                PlayerQuests.Entry e = entries.get(i);
                QuestDefs.QuestDef def = QuestDefs.byId(e.id);
                if (def == null || e.status != PlayerQuests.COMPLETE) return;
                if (def.type() == QuestType.GATHER) {
                    if (QuestItems.count(player.getInventory(), def.target()) < def.count()) {
                        e.status = PlayerQuests.ACCEPTED;
                        quests.setQuests(period, entries);
                        player.displayClientMessage(Component.translatable("message.shinobiarts.quest_need_items").withStyle(ChatFormatting.RED), true);
                        return;
                    }
                    if (!handIn(player, d, def.target(), def.count())) return;
                }
                e.status = PlayerQuests.CLAIMED;
                quests.setQuests(period, entries);
                reward(player, def.bottles(), def.ryo());
                giveScroll(player, e.scroll);
            }
        } else if (uid.startsWith("k:")) {
            int id = parseInt(uid.substring(2));
            VillageData village = VillageData.get(player.server);
            VillageData.KageQuest q = village.quest(d.getVillage(), id);
            int status = quests.kageStatus(d.getVillage(), id);
            if (q == null || (status != PlayerQuests.ACCEPTED && status != PlayerQuests.COMPLETE)) return;
            if (QuestItems.count(player.getInventory(), q.item) < q.count) {
                player.displayClientMessage(Component.translatable("message.shinobiarts.quest_need_items").withStyle(ChatFormatting.RED), true);
                return;
            }
            if (!handIn(player, d, q.item, q.count)) return;
            quests.setKageStatus(d.getVillage(), id, PlayerQuests.CLAIMED);
            reward(player, q.bottles, q.ryo);
        }
    }

    /**
     * Hands a quest's items in: they leave the player's inventory and go into the village storage. Nothing is
     * taken unless all of it fits; returns false (with a message) if the storage is full.
     */
    private static boolean handIn(ServerPlayer player, NinjaData d, String target, int count) {
        VillageData village = VillageData.get(player.server);
        if (!village.store(d.getVillage(), QuestItems.peek(player.getInventory(), target, count))) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.village_storage_full").withStyle(ChatFormatting.RED), true);
            return false;
        }
        QuestItems.take(player.getInventory(), target, count);
        return true;
    }

    /** The jutsu scroll a quest pays out, if it has one. */
    private static void giveScroll(ServerPlayer player, String jutsuId) {
        if (jutsuId.isEmpty() || !ModItems.JUTSU_SCROLLS.containsKey(jutsuId)) return;
        ItemStack stack = new ItemStack(ModItems.JUTSU_SCROLLS.get(jutsuId).get());
        player.sendSystemMessage(Component.translatable("message.shinobiarts.quest_scroll", stack.getHoverName()).withStyle(ChatFormatting.GOLD));
        if (!player.getInventory().add(stack) || !stack.isEmpty()) player.drop(stack, false);
    }

    private static void reward(ServerPlayer player, int bottles, long ryo) {
        if (bottles > 0) {
            ItemStack stack = new ItemStack(ModItems.EXP_BOTTLE.get(), bottles);
            while (!stack.isEmpty()) {
                ItemStack part = stack.split(Math.min(stack.getCount(), stack.getMaxStackSize()));
                player.getInventory().add(part);
                if (!part.isEmpty()) player.drop(part, false);
            }
        }
        if (ryo > 0) PlayerDataManager.addRyo(player, ryo);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.quest_claimed", bottles, PlayerDataManager.formatRyo(ryo))
                .withStyle(ChatFormatting.GOLD));
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8f, 1.3f);
    }

    /** Kage: posts "bring N of the item in your hand" with a reward (limited by the config). */
    private static void post(ServerPlayer player, NinjaData d, int count, int bottles, long ryo) {
        if (!d.isKage()) return;
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.kage_hold_item").withStyle(ChatFormatting.RED), true);
            return;
        }
        VillageData village = VillageData.get(player.server);
        long nowMs = System.currentTimeMillis();
        long wait = village.postCooldownLeft(d.getVillage(), nowMs);
        if (wait > 0) {                                     // one quest per kageQuestCooldownMinutes (60 by default)
            long mins = (wait + 59_999) / 60_000;
            player.displayClientMessage(Component.translatable("message.shinobiarts.kage_post_cooldown", mins).withStyle(ChatFormatting.RED), true);
            return;
        }
        if (village.quests(d.getVillage()).size() >= Config.i(Config.KAGE_MAX_QUESTS)) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.kage_too_many", Config.i(Config.KAGE_MAX_QUESTS))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(held.getItem());
        int n = Math.max(1, Math.min(64 * 36, count));
        int b = Math.max(0, Math.min(Config.i(Config.KAGE_MAX_BOTTLES), bottles));
        long r = Math.max(0, Math.min(Config.i(Config.KAGE_MAX_RYO), ryo));
        village.post(d.getVillage(), id.toString(), n, b, r, player.getGameProfile().getName());
        village.markPosted(d.getVillage(), nowMs);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.kage_posted", title(QuestType.GATHER, n, id.toString()))
                .withStyle(ChatFormatting.GREEN));
    }

    /** Kage: moves an online member of the village up or down one rank (up to Jonin, or Anbu if allowed). */
    private static void promote(ServerPlayer player, NinjaData d, String name, int direction) {
        if (!d.isKage()) return;
        ServerPlayer target = player.server.getPlayerList().getPlayerByName(name);
        NinjaData td = target == null ? null : NinjaData.get(target);
        if (td == null || !d.getVillage().equals(td.getVillage()) || target == player) return;
        Rank max = Config.b(Config.KAGE_PROMOTE_MAX) ? Rank.ANBU : Rank.JONIN;
        int next = td.getRank().ordinal() + (direction > 0 ? 1 : -1);
        if (next < 0 || next > max.ordinal()) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.kage_rank_limit").withStyle(ChatFormatting.RED), true);
            return;
        }
        Rank rank = Rank.values()[next];
        PlayerDataManager.setRank(target, rank);
        Component msg = Component.translatable("message.shinobiarts.kage_promoted", name, rank.displayName()).withStyle(ChatFormatting.GOLD);
        player.sendSystemMessage(msg);
        target.sendSystemMessage(Component.translatable("message.shinobiarts.you_were_ranked", rank.displayName(), player.getGameProfile().getName())
                .withStyle(ChatFormatting.GOLD));
    }

    /** Kage: appoints an online member of the village as a Village Advisor, or removes the title. */
    private static void toggleAdvisor(ServerPlayer player, NinjaData d, String name) {
        if (!d.isKage()) return;
        ServerPlayer target = player.server.getPlayerList().getPlayerByName(name);
        NinjaData td = target == null ? null : NinjaData.get(target);
        if (td == null || !d.getVillage().equals(td.getVillage())) return;
        boolean appoint = !d.getVillage().equals(td.getAdvisorOf());
        td.setAdvisorOf(appoint ? d.getVillage() : "");
        VillageManager.refresh(target);
        String village = Villages.name(d.getVillage());
        if (!appoint && td.isAdvisor()) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.advisor_by_permission", name).withStyle(ChatFormatting.YELLOW));
            return;
        }
        player.sendSystemMessage(Component.translatable(appoint ? "message.shinobiarts.advisor_appointed" : "message.shinobiarts.advisor_removed",
                name).withStyle(ChatFormatting.AQUA));
        if (target != player) {
            target.sendSystemMessage(Component.translatable(appoint ? "message.shinobiarts.you_advisor" : "message.shinobiarts.you_not_advisor",
                    village).withStyle(ChatFormatting.AQUA));
        }
    }

    /** Kage: the village storage, a double chest saved with the world. */
    private static void openStorage(ServerPlayer player, NinjaData d) {
        if (!d.isKage()) return;
        VillageData village = VillageData.get(player.server);
        com.shinobiarts.village.VillageStorageContainer container =
                new com.shinobiarts.village.VillageStorageContainer(village.storage(d.getVillage()), village);
        player.openMenu(new SimpleMenuProvider((id, inventory, p) -> ChestMenu.sixRows(id, inventory, container),
                Component.translatable("container.shinobiarts.village_storage", Villages.name(d.getVillage()))));
    }

    private static int parseInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
