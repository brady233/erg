package com.shinobiarts.quest;

import java.util.ArrayList;
import java.util.List;

/**
 * The random quest pool. Each period draws its quests from its own list (hourly = quick and easy,
 * monthly = long and well paid). Gather targets are item ids, or "#namespace:tag" for any item in a tag.
 * Rewards: EXP bottles (100 ninja XP each) and Ryo.
 */
public final class QuestDefs {
    public record QuestDef(String id, QuestPeriod period, QuestType type, int count, String target, int bottles, long ryo) {}

    private static final List<QuestDef> ALL = new ArrayList<>();
    private static final String LOGS = "#minecraft:logs";

    static {
        // hourly
        add("h_bandits", QuestPeriod.HOURLY, QuestType.KILL_BANDITS, 5, "", 2, 300);
        add("h_mobs", QuestPeriod.HOURLY, QuestType.KILL_MOBS, 10, "", 2, 200);
        add("h_logs", QuestPeriod.HOURLY, QuestType.GATHER, 16, LOGS, 1, 250);
        add("h_fish", QuestPeriod.HOURLY, QuestType.FISH, 3, "", 2, 250);
        add("h_player", QuestPeriod.HOURLY, QuestType.KILL_PLAYERS, 1, "", 3, 500);
        add("h_wheat", QuestPeriod.HOURLY, QuestType.GATHER, 16, "minecraft:wheat", 1, 200);
        // daily
        add("d_bandits", QuestPeriod.DAILY, QuestType.KILL_BANDITS, 15, "", 5, 1500);
        add("d_mobs", QuestPeriod.DAILY, QuestType.KILL_MOBS, 40, "", 4, 1000);
        add("d_logs", QuestPeriod.DAILY, QuestType.GATHER, 64, LOGS, 3, 1000);
        add("d_fish", QuestPeriod.DAILY, QuestType.FISH, 10, "", 4, 1200);
        add("d_players", QuestPeriod.DAILY, QuestType.KILL_PLAYERS, 3, "", 6, 2000);
        add("d_iron", QuestPeriod.DAILY, QuestType.GATHER, 16, "minecraft:iron_ingot", 4, 1500);
        add("d_bread", QuestPeriod.DAILY, QuestType.GATHER, 24, "minecraft:bread", 3, 800);
        // weekly
        add("w_bandits", QuestPeriod.WEEKLY, QuestType.KILL_BANDITS, 60, "", 20, 8000);
        add("w_mobs", QuestPeriod.WEEKLY, QuestType.KILL_MOBS, 200, "", 15, 6000);
        add("w_fish", QuestPeriod.WEEKLY, QuestType.FISH, 40, "", 15, 6000);
        add("w_players", QuestPeriod.WEEKLY, QuestType.KILL_PLAYERS, 10, "", 25, 10000);
        add("w_diamonds", QuestPeriod.WEEKLY, QuestType.GATHER, 8, "minecraft:diamond", 20, 8000);
        add("w_iron", QuestPeriod.WEEKLY, QuestType.GATHER, 64, "minecraft:iron_ingot", 15, 6000);
        // monthly
        add("m_bandits", QuestPeriod.MONTHLY, QuestType.KILL_BANDITS, 250, "", 60, 30000);
        add("m_players", QuestPeriod.MONTHLY, QuestType.KILL_PLAYERS, 30, "", 80, 40000);
        add("m_diamonds", QuestPeriod.MONTHLY, QuestType.GATHER, 32, "minecraft:diamond", 60, 30000);
        add("m_fish", QuestPeriod.MONTHLY, QuestType.FISH, 150, "", 50, 25000);
        add("m_mobs", QuestPeriod.MONTHLY, QuestType.KILL_MOBS, 1000, "", 50, 25000);
    }

    private QuestDefs() {}

    private static void add(String id, QuestPeriod period, QuestType type, int count, String target, int bottles, long ryo) {
        ALL.add(new QuestDef(id, period, type, count, target, bottles, ryo));
    }

    public static List<QuestDef> pool(QuestPeriod period) {
        List<QuestDef> out = new ArrayList<>();
        for (QuestDef d : ALL) {
            if (d.period() == period) out.add(d);
        }
        return out;
    }

    public static QuestDef byId(String id) {
        for (QuestDef d : ALL) {
            if (d.id().equals(id)) return d;
        }
        return null;
    }
}
