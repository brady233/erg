package com.shinobiarts.village;

import com.shinobiarts.Config;

import java.util.ArrayList;
import java.util.List;

/**
 * The villages, from the server config ("villages" list of "id:Display Name"). Default: the five great
 * villages. Membership comes from permissions (LuckPerms: shinobiarts.village.&lt;id&gt; and
 * shinobiarts.village.&lt;id&gt;.kage) or from /shinobi village and /shinobi kage.
 */
public final class Villages {
    public record Village(String id, String name) {}

    private Villages() {}

    public static List<Village> all() {
        List<Village> out = new ArrayList<>();
        for (String entry : Config.villages()) {
            int colon = entry.indexOf(':');
            if (colon <= 0 || colon == entry.length() - 1) continue;
            String id = entry.substring(0, colon).trim().toLowerCase(java.util.Locale.ROOT);
            if (!id.matches("[a-z0-9_]+") || byId(out, id) != null) continue;
            out.add(new Village(id, entry.substring(colon + 1).trim()));
        }
        return out;
    }

    private static Village byId(List<Village> list, String id) {
        for (Village v : list) {
            if (v.id().equals(id)) return v;
        }
        return null;
    }

    public static Village byId(String id) {
        return id == null || id.isEmpty() ? null : byId(all(), id);
    }

    /** Display name of a village id ("" or unknown ids show as-is). */
    public static String name(String id) {
        Village v = byId(id);
        return v != null ? v.name() : id;
    }
}
