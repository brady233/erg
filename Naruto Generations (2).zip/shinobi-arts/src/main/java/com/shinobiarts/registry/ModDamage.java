package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/** Custom damage types (defined in data/shinobiarts/damage_type/*.json) for proper death messages. */
public final class ModDamage {
    public static final ResourceKey<DamageType> JUTSU = ResourceKey.create(Registries.DAMAGE_TYPE, ShinobiArts.id("jutsu"));
    public static final ResourceKey<DamageType> AMATERASU = ResourceKey.create(Registries.DAMAGE_TYPE, ShinobiArts.id("amaterasu"));
    /** Kamui snap: ignores armor, shields and protection enchantments (data/minecraft/tags/damage_type). */
    public static final ResourceKey<DamageType> KAMUI = ResourceKey.create(Registries.DAMAGE_TYPE, ShinobiArts.id("kamui"));
    /** Tsukuyomi: the mind breaks, so armor doesn't help (data/minecraft/tags/damage_type). */
    public static final ResourceKey<DamageType> TSUKUYOMI = ResourceKey.create(Registries.DAMAGE_TYPE, ShinobiArts.id("tsukuyomi"));

    /** The Gate of Death: nothing can stop it (data/minecraft/tags/damage_type). */
    public static final ResourceKey<DamageType> GATE_OF_DEATH = ResourceKey.create(Registries.DAMAGE_TYPE, ShinobiArts.id("gate_of_death"));

    /**
     * Jutsu damage. It remembers which jutsu its caster last used, so the death message can name it
     * ("Steve was killed by Alex's Chidori").
     */
    public static DamageSource jutsu(Level level, @Nullable Entity direct, @Nullable Entity causing) {
        String jutsuId = null;
        if (direct instanceof com.shinobiarts.entity.JutsuProjectile jp) jutsuId = jp.jutsuId();    // named when it was thrown
        else if (direct instanceof com.shinobiarts.entity.MajesticFlame mf) jutsuId = mf.jutsuId();
        if (jutsuId == null) jutsuId = com.shinobiarts.jutsu.JutsuUtil.lastJutsu(causing != null ? causing : direct);
        return new JutsuSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(JUTSU), direct, causing, jutsuId);
    }

    public static DamageSource gateOfDeath(Level level) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(GATE_OF_DEATH));
    }

    /** A jutsu hit that knows the jutsu's name. */
    public static final class JutsuSource extends DamageSource {
        @Nullable
        private final String jutsuId;

        JutsuSource(net.minecraft.core.Holder<DamageType> type, @Nullable Entity direct, @Nullable Entity causing, @Nullable String jutsuId) {
            super(type, direct, causing);
            this.jutsuId = jutsuId;
        }

        @Nullable
        public String jutsuId() {
            return jutsuId;
        }

        @Override
        public net.minecraft.network.chat.Component getLocalizedDeathMessage(net.minecraft.world.entity.LivingEntity killed) {
            com.shinobiarts.jutsu.Jutsu jutsu = jutsuId == null ? null : com.shinobiarts.jutsu.Jutsus.get(jutsuId);
            if (jutsu == null) return super.getLocalizedDeathMessage(killed);
            Entity by = getEntity() != null ? getEntity() : getDirectEntity();
            if (by instanceof com.shinobiarts.entity.ShadowClone clone && clone.level() instanceof net.minecraft.server.level.ServerLevel sl
                    && clone.getOwnerUUID() != null) {
                Entity owner = sl.getEntity(clone.getOwnerUUID());
                if (owner != null) by = owner;               // a clone's jutsu counts as its owner's
            }
            net.minecraft.network.chat.Component name = jutsu.displayName();
            if (by == null) {
                return net.minecraft.network.chat.Component.translatable("death.attack.shinobiarts.jutsu.named", killed.getDisplayName(), name);
            }
            return net.minecraft.network.chat.Component.translatable("death.attack.shinobiarts.jutsu.named.player",
                    killed.getDisplayName(), by.getDisplayName(), name);
        }
    }

    public static DamageSource amaterasu(Level level) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(AMATERASU));
    }

    public static DamageSource kamui(Level level, Entity attacker) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(KAMUI), attacker, attacker);
    }

    public static DamageSource tsukuyomi(Level level, @Nullable Entity caster) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(TSUKUYOMI), caster, caster);
    }

    private ModDamage() {}
}
