package com.shinobiarts.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> the caster: your mind is in {@code targetId} for {@code ticks} ticks (0 = it's back). See MindTransfer. */
public class MindLinkPacket {
    private final int casterId, targetId, ticks;

    public MindLinkPacket(int casterId, int targetId, int ticks) {
        this.casterId = casterId;
        this.targetId = targetId;
        this.ticks = ticks;
    }

    public MindLinkPacket(FriendlyByteBuf buf) {
        this.casterId = buf.readVarInt();
        this.targetId = buf.readVarInt();
        this.ticks = buf.readVarInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(casterId);
        buf.writeVarInt(targetId);
        buf.writeVarInt(ticks);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.shinobiarts.client.MindTransferClient.set(targetId, ticks));
    }
}
