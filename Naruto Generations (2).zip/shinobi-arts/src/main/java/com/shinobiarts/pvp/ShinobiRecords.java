package com.shinobiarts.pvp;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.village.Villages;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Every ninja's PvP record and the bounties on their heads, kept for the whole server (players who are offline
 * included), for the bounty board and the leaderboard (/shinobi lb):
 * <ul>
 *   <li>Kills count when the kill is rewarded (PvpRewards: no farming alts or the same victim again). Deaths count
 *       for any death at another player's hands. Streaks too.</li>
 *   <li>A bounty is Ryo put on a player's head (/bounty or the Bounties page of the ninja menu). Whoever kills them
 *       takes all of it.</li>
 *   <li>A snapshot of each ninja's card (name, village, rank, level, clan) is kept up to date while they play.</li>
 * </ul>
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ShinobiRecords extends SavedData {
    public static final class Record {
        public UUID id;
        public String name = "";
        public int kills, deaths, streak, bestStreak, level;
        public long bounty;
        public String village = "", rank = "genin", clan = "";

        CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putUUID("Id", id);
            t.putString("Name", name);
            t.putInt("Kills", kills);
            t.putInt("Deaths", deaths);
            t.putInt("Streak", streak);
            t.putInt("Best", bestStreak);
            t.putInt("Level", level);
            t.putLong("Bounty", bounty);
            t.putString("Village", village);
            t.putString("Rank", rank);
            t.putString("Clan", clan);
            return t;
        }

        static Record load(CompoundTag t) {
            Record r = new Record();
            r.id = t.getUUID("Id");
            r.name = t.getString("Name");
            r.kills = t.getInt("Kills");
            r.deaths = t.getInt("Deaths");
            r.streak = t.getInt("Streak");
            r.bestStreak = t.getInt("Best");
            r.level = t.getInt("Level");
            r.bounty = t.getLong("Bounty");
            r.village = t.getString("Village");
            r.rank = t.getString("Rank");
            r.clan = t.getString("Clan");
            return r;
        }

        public float kd() {
            return kills / (float) Math.max(1, deaths);
        }

        /** The ninja info card, for the client. */
        public CompoundTag card(MinecraftServer server) {
            CompoundTag t = save();
            t.putBoolean("Online", server.getPlayerList().getPlayer(id) != null);
            return t;
        }
    }

    private final Map<UUID, Record> all = new HashMap<>();

    public static ShinobiRecords get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(ShinobiRecords::load, ShinobiRecords::new, "shinobiarts_records");
    }

    static ShinobiRecords load(CompoundTag tag) {
        ShinobiRecords r = new ShinobiRecords();
        ListTag list = tag.getList("Records", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            Record rec = Record.load(list.getCompound(i));
            r.all.put(rec.id, rec);
        }
        return r;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Record r : all.values()) list.add(r.save());
        tag.put("Records", list);
        return tag;
    }

    /** A player's record, made if they don't have one, with their card brought up to date. */
    public Record of(ServerPlayer p) {
        Record r = all.computeIfAbsent(p.getUUID(), id -> {
            Record n = new Record();
            n.id = id;
            return n;
        });
        r.name = p.getGameProfile().getName();
        NinjaData d = NinjaData.get(p);
        if (d != null && d.isInitialized()) {
            r.level = d.getLevel();
            r.rank = d.getRank().id();
            r.village = d.getVillage().isEmpty() ? "" : Villages.name(d.getVillage());
            r.clan = Component.Serializer.toJson(d.getClan().displayName());
        }
        setDirty();
        return r;
    }

    @Nullable
    public Record byName(String name) {
        for (Record r : all.values()) if (r.name.equalsIgnoreCase(name)) return r;
        return null;
    }

    public List<Record> records() {
        return new ArrayList<>(all.values());
    }

    /** Everyone with a bounty on them, biggest first. */
    public List<Record> wanted() {
        List<Record> out = new ArrayList<>();
        for (Record r : all.values()) if (r.bounty > 0) out.add(r);
        out.sort(Comparator.comparingLong((Record r) -> r.bounty).reversed());
        return out;
    }

    // ---------------------------------------------------------------- bounties

    /** Puts {@code amount} Ryo on {@code target}'s head (paid by {@code by}). Returns false with a message if not. */
    public static boolean post(ServerPlayer by, ServerPlayer target, long amount) {
        long min = Config.i(Config.BOUNTY_MIN);
        if (target == by) {
            by.sendSystemMessage(Component.translatable("message.shinobiarts.bounty_self").withStyle(ChatFormatting.RED));
            return false;
        }
        if (amount < min) {
            by.sendSystemMessage(Component.translatable("message.shinobiarts.bounty_min", PlayerDataManager.formatRyo(min)).withStyle(ChatFormatting.RED));
            return false;
        }
        if (!PlayerDataManager.trySpendRyo(by, amount)) {
            by.sendSystemMessage(Component.translatable("message.shinobiarts.bounty_poor", PlayerDataManager.formatRyo(amount)).withStyle(ChatFormatting.RED));
            return false;
        }
        ShinobiRecords records = get(by.server);
        Record r = records.of(target);
        records.of(by);
        r.bounty += amount;
        records.setDirty();
        by.server.getPlayerList().broadcastSystemMessage(Component.translatable("message.shinobiarts.bounty_posted",
                by.getGameProfile().getName(), PlayerDataManager.formatRyo(amount), target.getGameProfile().getName(),
                PlayerDataManager.formatRyo(r.bounty)).withStyle(ChatFormatting.GOLD), false);
        target.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 1f, 0.6f);
        return true;
    }

    /** Sends the bounty board (every wanted ninja's card) to a player. */
    public static void sendBoard(ServerPlayer to) {
        ShinobiRecords records = get(to.server);
        records.of(to);
        CompoundTag tag = new CompoundTag();
        ListTag list = new ListTag();
        for (Record r : records.wanted()) list.add(r.card(to.server));
        tag.put("Wanted", list);
        tag.putLong("Ryo", NinjaData.get(to) == null ? 0 : NinjaData.get(to).getRyo());
        tag.putLong("Min", Config.i(Config.BOUNTY_MIN));
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> to), new com.shinobiarts.network.BountyBoardPacket(tag));
    }

    // ---------------------------------------------------------------- events

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) get(p.server).of(p);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) get(p.server).of(p);
    }

    /** A rewarded PvP kill (from PvpRewards): it counts on the leaderboard. */
    public static void rewardedKill(ServerPlayer killer, ServerPlayer victim) {
        ShinobiRecords records = get(killer.server);
        Record k = records.of(killer);
        k.kills++;
        k.streak++;
        k.bestStreak = Math.max(k.bestStreak, k.streak);
        records.setDirty();
        if (k.streak >= 5 && k.streak % 5 == 0) {
            killer.server.getPlayerList().broadcastSystemMessage(Component.translatable("message.shinobiarts.streak",
                    killer.getGameProfile().getName(), k.streak).withStyle(ChatFormatting.RED), false);
        }
    }

    /** Any death at another player's hands: a death on the record, the streak's over, and the bounty is claimed. */
    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onDeath(LivingDeathEvent event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer victim)) return;
        ServerPlayer killer = PvpRewards.responsiblePlayer(event.getSource());
        if (killer == null || killer == victim) return;
        ShinobiRecords records = get(victim.server);
        Record v = records.of(victim);
        v.deaths++;
        v.streak = 0;
        records.setDirty();
        NinjaData kd = NinjaData.get(killer);
        if (kd != null) kd.rememberSoul(victim);                  // for Edo Tensei
        if (v.bounty > 0) {
            long prize = v.bounty;
            v.bounty = 0;
            PlayerDataManager.addRyo(killer, prize);
            killer.server.getPlayerList().broadcastSystemMessage(Component.translatable("message.shinobiarts.bounty_claimed",
                    killer.getGameProfile().getName(), PlayerDataManager.formatRyo(prize), victim.getGameProfile().getName())
                    .withStyle(ChatFormatting.GOLD), false);
            killer.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 0.7f);
        }
    }
}
