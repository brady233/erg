package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.MangekyouDesign;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * Draws the eyes on the face of a player (or shadow clone): their Sharingan stage while it's on (the Mangekyou in its
 * pattern), the Byakugan while that's on, or 3 tomoe for a Sharingan worn in the dojutsu slot.
 */
public class SharinganEyesLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation[] TOMOE = new ResourceLocation[4];
    private static final ResourceLocation[] MANGEKYOU = new ResourceLocation[MangekyouDesign.values().length];
    private static final ResourceLocation BYAKUGAN = new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/byakugan.png");
    private static final ResourceLocation RINNEGAN = new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/rinnegan.png");

    static {
        for (int i = 1; i <= 3; i++) TOMOE[i] = new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/sharingan_" + i + ".png");
        for (MangekyouDesign d : MangekyouDesign.values()) MANGEKYOU[d.ordinal()] = mangekyouTexture(d);
    }

    private final HumanoidModel<T> eyes;

    public SharinganEyesLayer(RenderLayerParent<T, M> parent, EntityModelSet models) {
        super(parent);
        this.eyes = new HumanoidModel<>(models.bakeLayer(ClientSetup.SHARINGAN_LAYER));
    }

    /** Itachi's pattern keeps the original file name (sharingan_4.png). */
    private static ResourceLocation mangekyouTexture(MangekyouDesign d) {
        String name = d == MangekyouDesign.ITACHI ? "sharingan_4" : "sharingan_4_" + d.id();
        return new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/" + name + ".png");
    }

    public static ResourceLocation texture(int look) {
        int stage = SharinganManager.lookStage(look);
        if (stage == SharinganManager.LOOK_BYAKUGAN) return BYAKUGAN;
        if (stage == SharinganManager.LOOK_RINNEGAN) return RINNEGAN;
        return stage >= 4 ? MANGEKYOU[SharinganManager.lookDesign(look).ordinal()] : TOMOE[Math.max(1, stage)];
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        int look = ClientEyes.look(entity);
        if (SharinganManager.lookStage(look) <= 0 || entity.isInvisible()) return;
        getParentModel().copyPropertiesTo(eyes);
        eyes.setAllVisible(false);
        eyes.head.visible = true;
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(texture(look)));
        eyes.renderToBuffer(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
    }
}
