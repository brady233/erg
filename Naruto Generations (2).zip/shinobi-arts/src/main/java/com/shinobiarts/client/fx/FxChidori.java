package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Chidori in hand (entityA = the user): lightning has taken over the hand. A white-hot core in the fist, a dense knot
 * of bolts crackling out of it in every direction (new ones every tick), more running up the forearm, and a cold blue
 * glow round it all. Drawn at the right hand: in first person, low in front of the camera where your hand is.
 */
final class FxChidori {
    private FxChidori() {}

    static void hand(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        float partial = c.partial();
        Minecraft mc = Minecraft.getInstance();
        float yaw = Mth.rotLerp(partial, e.yRotO, e.getYRot());
        float pitch = Mth.lerp(partial, e.xRotO, e.getXRot());
        Vec3 look = Vec3.directionFromRotation(pitch, yaw);
        Vec3 flat = Vec3.directionFromRotation(0, yaw);
        Vec3 right = new Vec3(-flat.z, 0, flat.x);
        Vec3 eye = e.getEyePosition(partial);
        boolean firstPerson = e == mc.player && mc.options.getCameraType().isFirstPerson();
        Vec3 fist, elbow;
        if (firstPerson) {
            Vec3 up = right.cross(look).normalize();
            fist = eye.add(look.scale(0.75)).add(right.scale(0.42)).add(up.scale(-0.38));
            elbow = fist.add(right.scale(0.25)).add(up.scale(-0.35)).subtract(look.scale(0.25));
        } else {
            // the arm held low and forward at the side, the way it's carried at a run
            Vec3 base = e.getPosition(partial);
            fist = base.add(right.scale(0.42)).add(flat.scale(0.35)).add(0, 0.75, 0);
            elbow = base.add(right.scale(0.4)).add(flat.scale(0.05)).add(0, 1.05, 0);
        }
        long tick = (long) c.age();
        RandomSource r = RandomSource.create(c.fx().seed * 31 + tick * 7919);
        VertexConsumer add = FxDraw.additive(c.buffers());
        float flicker = 0.8f + 0.2f * r.nextFloat();
        // the glow and the white-hot core
        FxDraw.billboard(add, c.ps(), c.camera(), fist, 1.1f * flicker, 1.1f * flicker, r.nextFloat() * 6, FxDraw.addColor(0x5A8CFF, 0.55f), FxDraw.FULL);
        FxDraw.billboard(add, c.ps(), c.camera(), fist, 0.55f, 0.55f, r.nextFloat() * 6, FxDraw.addColor(0xCFE2FF, 0.9f), FxDraw.FULL);
        FxDraw.billboard(add, c.ps(), c.camera(), fist, 0.25f, 0.25f, 0, FxDraw.addColor(0xFFFFFF, 1f), FxDraw.FULL);
        // the knot of bolts round the fist
        int bolts = firstPerson ? 10 : 14;
        for (int i = 0; i < bolts; i++) {
            Vec3 d = new Vec3(r.nextGaussian(), r.nextGaussian() * 0.8, r.nextGaussian()).normalize();
            float len = (firstPerson ? 0.25f : 0.4f) + r.nextFloat() * (firstPerson ? 0.35f : 0.75f);
            Vec3 tip = fist.add(d.scale(len));
            int rgb = i % 3 == 0 ? 0xFFFFFF : 0x9CC8FF;
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), fist, tip, c.fx().seed + tick * 13 + i, len * 0.35f, firstPerson ? 0.02f : 0.035f, rgb, 0.95f, 1);
        }
        // and up the forearm
        for (int i = 0; i < 3; i++) {
            Vec3 a = fist.lerp(elbow, r.nextFloat() * 0.3f);
            Vec3 b = fist.lerp(elbow, 0.5f + r.nextFloat() * 0.5f);
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), a, b, c.fx().seed + tick * 17 + 50 + i, 0.12f, firstPerson ? 0.015f : 0.025f, 0xBFD8FF, 0.8f, 0);
        }
    }
}
