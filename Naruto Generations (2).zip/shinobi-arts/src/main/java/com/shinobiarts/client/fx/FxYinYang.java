package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Yin-Yang Release: the black Yin blades' cuts, and the Yang Burst's dome of light. */
final class FxYinYang {
    private FxYinYang() {}

    /** One cut (a = where it starts, b = how far it reaches, size = the cut's tilt in degrees): a black crescent sweeping across. */
    static void slash(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        Vec3 fwd = b.subtract(a);
        double reach = fwd.length();
        if (reach < 1e-3) return;
        fwd = fwd.scale(1 / reach);
        Vec3 side = FxDraw.perpendicular(fwd);
        Vec3 up = fwd.cross(side).normalize();
        double tilt = Math.toRadians(c.fx().size);
        Vec3 across = side.scale(Math.cos(tilt)).add(up.scale(Math.sin(tilt)));
        float p = c.progress();
        float sweep = Mth.clamp(p * 2.2f, 0f, 1f), fade = 1f - Mth.clamp((p - 0.45f) / 0.55f, 0f, 1f);
        if (fade <= 0) return;
        List<Vec3> arc = new ArrayList<>();
        for (int i = 0; i <= 18; i++) {
            float u = i / 18f;
            if (u > sweep) break;
            double ang = Math.toRadians(-70 + 140 * u);
            arc.add(a.add(fwd.scale(Math.cos(ang) * reach * 0.6 + 1.0)).add(across.scale(Math.sin(ang) * reach * 0.6)));
        }
        if (arc.size() < 2) return;
        FxDraw.ribbon(FxDraw.lit(c.buffers()), c.ps(), c.cam(), arc, 1.1f, 0.6f, FxDraw.color(0x0A0410, 0.2f * fade),
                FxDraw.color(0x14081E, 0.95f * fade), FxDraw.FULL);
        FxDraw.ribbon(FxDraw.additive(c.buffers()), c.ps(), c.cam(), arc, 0.35f, 0.6f, FxDraw.addColor(0x6A2AB0, 0f),
                FxDraw.addColor(0xB070FF, 0.6f * fade), FxDraw.FULL);
    }

    /** The Yang Burst (a = centre, size = radius): a white-gold flash and a dome of light swelling out and fading. */
    static void burst(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        float p = c.progress(), R = c.fx().size;
        float grow = FxDraw.smooth(Math.min(1f, p * 1.6f));
        float fade = 1f - FxDraw.smooth(p);
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.sphere(add, c.ps(), o, R * grow, 14, 22, FxDraw.addColor(0xFFE8A0, 0.35f * fade), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), o, R * 0.45f * grow, 12, 18, FxDraw.addColor(0xFFFFFF, 0.6f * fade), FxDraw.FULL);
        FxDraw.ring(add, c.ps(), new Vec3(o.x, FxDraw.groundY(o) + 0.05, o.z), new Vec3(0, 1, 0), R * grow * 1.1f, 1.2f, 64,
                FxDraw.addColor(0xFFF0C0, 0.7f * fade), FxDraw.addColor(0xFFC060, 0f), FxDraw.FULL);
    }
}
