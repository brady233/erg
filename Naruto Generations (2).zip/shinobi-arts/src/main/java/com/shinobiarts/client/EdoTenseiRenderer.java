package com.shinobiarts.client;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.blaze3d.vertex.PoseStack;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.EdoTensei;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.entity.SkullBlockEntity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Draws a soul brought back by Edo Tensei: the dead ninja's own skin (looked up like a player head's, so it works
 * even when they're offline), cracked all over with the whites of the eyes gone black. While it's still in its
 * coffin it rises with it; while it's broken apart, pieces of it are missing and come back one by one.
 */
public class EdoTenseiRenderer extends HumanoidMobRenderer<EdoTensei, PlayerModel<EdoTensei>> {
    static final ResourceLocation CRACKS = new ResourceLocation(ShinobiArts.MODID, "textures/entity/edo_tensei/cracks.png");

    private final PlayerModel<EdoTensei> wide, slim;

    public EdoTenseiRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
        this.wide = getModel();
        this.slim = new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM), true);
        this.addLayer(new Cracks(this, new PlayerModel<>(context.bakeLayer(ClientSetup.EDO_CRACKS_LAYER), false),
                new PlayerModel<>(context.bakeLayer(ClientSetup.EDO_CRACKS_SLIM_LAYER), true)));
    }

    @Override
    public void render(EdoTensei edo, float yaw, float partial, PoseStack ps, MultiBufferSource buffers, int light) {
        Skin skin = skin(edo);
        this.model = skin.slim() ? slim : wide;
        // still in the coffin: it comes up out of the ground with it
        int risen = edo.risen();
        float sink = 0f;
        if (risen < EdoTensei.RISE) {
            float t = Mth.clamp((risen + partial) / EdoTensei.RISE, 0f, 1f);
            sink = (1f - t * t * (3 - 2 * t)) * 2.45f;
        }
        // broken apart: some limbs and the head are missing, then they come back one at a time
        ModelPart[][] pieces = {
                {model.leftArm, model.leftSleeve}, {model.rightLeg, model.rightPants}, {model.head, model.hat},
                {model.rightArm, model.rightSleeve}, {model.leftLeg, model.leftPants}};
        int crumble = edo.crumble();
        if (crumble > 0) {
            float back = 1f - (crumble - partial) / EdoTensei.REFORM;        // 0 just broken, 1 whole again
            int seed = edo.getId();
            for (int i = 0; i < pieces.length; i++) {
                boolean broken = ((seed >> i) & 1) == 1 || i == 2 || i == 0;
                boolean shown = !broken || back > 0.35f + i * 0.11f;
                for (ModelPart part : pieces[i]) part.visible = shown;
            }
        }
        ps.pushPose();
        if (sink > 0f) ps.translate(0, -sink, 0);
        if (crumble > 0) ps.translate((edo.getRandom().nextFloat() - 0.5f) * 0.03f, 0, (edo.getRandom().nextFloat() - 0.5f) * 0.03f);
        super.render(edo, yaw, partial, ps, buffers, light);
        ps.popPose();
        for (ModelPart[] piece : pieces) for (ModelPart part : piece) part.visible = true;
    }

    @Override
    public ResourceLocation getTextureLocation(EdoTensei edo) {
        return skin(edo).texture();
    }

    // ---------------------------------------------------------------- the dead ninja's skin

    private record Skin(ResourceLocation texture, boolean slim) {}

    /** The nameless souls' skins (a cloaked wanderer, a village guard, a swordsman). */
    private static final ResourceLocation[] NAMELESS = {
            new ResourceLocation(ShinobiArts.MODID, "textures/entity/edo_tensei/souls/soul_0.png"),
            new ResourceLocation(ShinobiArts.MODID, "textures/entity/edo_tensei/souls/soul_1.png"),
            new ResourceLocation(ShinobiArts.MODID, "textures/entity/edo_tensei/souls/soul_2.png")};

    /** Skins fetched for souls who aren't online (filled in by the same lookup player heads use). */
    private static final Map<UUID, GameProfile> PROFILES = new ConcurrentHashMap<>();
    private static final Map<UUID, Boolean> ASKED = new ConcurrentHashMap<>();

    private static Skin skin(EdoTensei edo) {
        UUID soul = edo.getSoulUUID();
        if (soul == null) return new Skin(NAMELESS[Math.floorMod(edo.getUUID().hashCode(), NAMELESS.length)], false);
        Minecraft mc = Minecraft.getInstance();
        ClientPacketListener connection = mc.getConnection();
        PlayerInfo info = connection == null ? null : connection.getPlayerInfo(soul);
        if (info != null) return new Skin(info.getSkinLocation(), "slim".equals(info.getModelName()));
        GameProfile filled = PROFILES.get(soul);
        if (filled == null) {
            if (ASKED.putIfAbsent(soul, true) == null) {
                String name = edo.hasCustomName() ? edo.getCustomName().getString() : null;
                SkullBlockEntity.updateGameprofile(new GameProfile(soul, name), profile -> {
                    if (profile != null) PROFILES.put(soul, profile);
                });
            }
            return fallback(soul);
        }
        Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> textures = mc.getSkinManager().getInsecureSkinInformation(filled);
        MinecraftProfileTexture tex = textures.get(MinecraftProfileTexture.Type.SKIN);
        if (tex == null) return fallback(soul);
        return new Skin(mc.getSkinManager().registerTexture(tex, MinecraftProfileTexture.Type.SKIN), "slim".equals(tex.getMetadata("model")));
    }

    private static Skin fallback(UUID soul) {
        return new Skin(DefaultPlayerSkin.getDefaultSkin(soul), "slim".equals(DefaultPlayerSkin.getSkinModelName(soul)));
    }

    // ---------------------------------------------------------------- the cracks

    /**
     * The cracks and black eyes over the whole body: drawn on a body a hair bigger than the skin's outer layer (so
     * they cover jackets, sleeves and trousers too), posed like the body and missing the same pieces.
     */
    private final class Cracks extends RenderLayer<EdoTensei, PlayerModel<EdoTensei>> {
        private final PlayerModel<EdoTensei> shellWide, shellSlim;

        Cracks(LivingEntityRenderer<EdoTensei, PlayerModel<EdoTensei>> parent, PlayerModel<EdoTensei> wide, PlayerModel<EdoTensei> slim) {
            super(parent);
            this.shellWide = wide;
            this.shellSlim = slim;
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buffers, int light, EdoTensei edo, float limbSwing, float limbAmount,
                           float partial, float age, float headYaw, float headPitch) {
            if (edo.isInvisible()) return;
            PlayerModel<EdoTensei> body = getParentModel();
            PlayerModel<EdoTensei> shell = body == EdoTenseiRenderer.this.slim ? shellSlim : shellWide;
            body.copyPropertiesTo(shell);
            shell.head.visible = body.head.visible;
            shell.body.visible = body.body.visible;
            shell.leftArm.visible = body.leftArm.visible;
            shell.rightArm.visible = body.rightArm.visible;
            shell.leftLeg.visible = body.leftLeg.visible;
            shell.rightLeg.visible = body.rightLeg.visible;
            // the shell's own outer layer would sit even further out: only its main boxes carry the cracks
            shell.hat.visible = shell.jacket.visible = shell.leftSleeve.visible = shell.rightSleeve.visible = false;
            shell.leftPants.visible = shell.rightPants.visible = false;
            shell.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucent(CRACKS)), light,
                    LivingEntityRenderer.getOverlayCoords(edo, 0f), 1f, 1f, 1f, 1f);
        }
    }
}
