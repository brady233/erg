package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.DojutsuSlot;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.Slot;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.ContainerScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.lang.reflect.Field;

/**
 * Draws the dojutsu slot's frame in the inventory screens (vanilla's background pictures have no frame there),
 * and in the creative inventory tab moves the slot from where the game would put it (on top of the hotbar) to its
 * own spot next to the off-hand slot.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class DojutsuSlotScreens {
    /** The slot's spot in the creative inventory tab: left of the off-hand slot. */
    public static final int CREATIVE_X = 16, CREATIVE_Y = 20;

    private static Field slotX, slotY;
    private static boolean fieldsLooked;
    /** The menu the creative listener is attached to (a new player object gets a new menu). */
    private static net.minecraft.world.inventory.AbstractContainerMenu listening;

    private DojutsuSlotScreens() {}

    /** Backups for adding the slot to the client's own player (EntityJoinLevelEvent does it first). */
    @SubscribeEvent
    public static void onLoggingIn(ClientPlayerNetworkEvent.LoggingIn event) {
        if (event.getPlayer() != null) DojutsuSlot.addTo(event.getPlayer());
    }

    @SubscribeEvent
    public static void onRespawn(ClientPlayerNetworkEvent.Clone event) {
        if (event.getNewPlayer() != null) DojutsuSlot.addTo(event.getNewPlayer());
    }

    @SubscribeEvent
    public static void onBackground(ContainerScreenEvent.Render.Background event) {
        AbstractContainerScreen<?> screen = event.getContainerScreen();
        GuiGraphics g = event.getGuiGraphics();
        if (screen instanceof InventoryScreen) {
            Slot slot = DojutsuSlot.find(screen.getMenu());
            if (slot != null) frame(g, screen.getGuiLeft() + slot.x - 1, screen.getGuiTop() + slot.y - 1);
        } else if (screen instanceof CreativeModeInventoryScreen creative) {
            listenInCreative();
            Slot slot = DojutsuSlot.find(creative.getMenu()); // only there while the inventory tab is open
            if (slot == null) return;
            if (slot.x != CREATIVE_X || slot.y != CREATIVE_Y) move(slot, CREATIVE_X, CREATIVE_Y);
            frame(g, screen.getGuiLeft() + slot.x - 1, screen.getGuiTop() + slot.y - 1);
        }
    }

    /**
     * In creative, the game tells the server about changes to its own 46 inventory slots only. This listener sends
     * the dojutsu slot's changes (made in the creative inventory tab) with a packet of our own.
     */
    private static void listenInCreative() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || listening == mc.player.inventoryMenu) return;
        listening = mc.player.inventoryMenu;
        listening.addSlotListener(new net.minecraft.world.inventory.ContainerListener() {
            @Override
            public void slotChanged(net.minecraft.world.inventory.AbstractContainerMenu menu, int index, net.minecraft.world.item.ItemStack stack) {
                Slot slot = DojutsuSlot.find(menu);
                Minecraft m = Minecraft.getInstance();
                if (slot != null && slot.index == index && m.player != null && m.player.isCreative()
                        && m.screen instanceof CreativeModeInventoryScreen) {
                    com.shinobiarts.network.ModNetwork.toServer(new com.shinobiarts.network.DojutsuSlotPacket(stack.copy()));
                }
            }

            @Override
            public void dataChanged(net.minecraft.world.inventory.AbstractContainerMenu menu, int id, int value) {
            }
        });
    }

    /** A vanilla-looking 18 x 18 slot: dark top-left edge, white bottom-right edge, grey inside. */
    private static void frame(GuiGraphics g, int x, int y) {
        g.fill(x, y, x + 18, y + 18, 0xFF8B8B8B);
        g.fill(x, y, x + 17, y + 1, 0xFF373737);
        g.fill(x, y, x + 1, y + 17, 0xFF373737);
        g.fill(x + 1, y + 17, x + 18, y + 18, 0xFFFFFFFF);
        g.fill(x + 17, y + 1, x + 18, y + 18, 0xFFFFFFFF);
    }

    /**
     * Slot.x and Slot.y are final, so they're set by reflection. The fields are found by probing a slot with known
     * coordinates, which works under any mappings.
     */
    private static void move(Slot slot, int x, int y) {
        if (!fieldsLooked) {
            fieldsLooked = true;
            try {
                Slot probe = new Slot(new net.minecraft.world.SimpleContainer(1), 0, 12345, 23456);
                for (Field f : Slot.class.getDeclaredFields()) {
                    if (f.getType() != int.class || java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                    f.setAccessible(true);
                    int v = f.getInt(probe);
                    if (v == 12345) slotX = f;
                    else if (v == 23456) slotY = f;
                }
            } catch (ReflectiveOperationException | RuntimeException e) {
                ShinobiArts.LOGGER.warn("Could not find Slot.x/y; the dojutsu slot stays where the creative tab puts it", e);
            }
        }
        if (slotX == null || slotY == null) return;
        try {
            slotX.setInt(slot, x);
            slotY.setInt(slot, y);
        } catch (ReflectiveOperationException | RuntimeException e) {
            slotX = slotY = null;
        }
    }

    /** True while the local player's inventory menu has the slot (for debugging / other code). */
    public static boolean present() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && DojutsuSlot.find(mc.player.inventoryMenu) != null;
    }
}
