package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.JutsuMesh;
import com.shinobiarts.entity.EdoTensei;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Edo Tensei's effects: the coffin coming up out of the ground (its lid falling open, then sinking away again), the
 * sacrifice wrapped in flakes of dust, the dust streaming to the coffin, a reanimated body breaking apart and drifting
 * back together, and the soul's release.
 */
final class FxEdo {
    private FxEdo() {}

    static final ResourceLocation COFFIN = new ResourceLocation(ShinobiArts.MODID, "textures/entity/edo_tensei/coffin.png");
    /** Light and dark flakes of dust, and the paper-pale ones among them. */
    private static final int ASH = 0xB8AD9A, ASH_DARK = 0x5F574D, PAPER = 0xE2D9C2;
    /** Where the lid's hinge sits on the coffin (its bottom front edge, on top of the plinth). */
    private static final float HINGE_Y = 0.0f, HINGE_Z = 0.4995f;
    /** How deep the coffin starts (and ends) under the ground. */
    private static final float DEPTH = 2.45f;

    // ---------------------------------------------------------------- the coffin

    /** The coffin (a = where it stands, b = a point it faces): it rises, its lid falls forward, and later it sinks back. */
    static void coffin(FxClient.Ctx c) {
        List<JutsuMesh.Group> mesh = JutsuMesh.get("edo_coffin");
        if (mesh.size() < 2) return;
        float age = c.age();
        Vec3 at = c.fx().a;
        Vec3 face = c.fx().b.subtract(at);
        face = new Vec3(face.x, 0, face.z);
        face = face.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : face.normalize();
        float up = FxDraw.smooth(Mth.clamp(age / EdoTensei.RISE, 0f, 1f));
        float sinkStart = EdoTensei.FREE + 12;
        float down = FxDraw.smooth(Mth.clamp((age - sinkStart) / (c.fx().ticks - sinkStart - 2), 0f, 1f));
        float y = -(1f - up) * DEPTH - down * (DEPTH + 0.3f);
        // a little shudder as it breaks out of the ground
        float shake = age < EdoTensei.RISE ? Mth.sin(age * 2.7f) * 0.02f * (1f - up) : 0f;

        Vec3 z = face, yAxis = new Vec3(0, 1, 0), x = yAxis.cross(z).normalize();
        PoseStack ps = c.ps();
        ps.pushPose();
        ps.translate(at.x + x.x * shake, at.y + y, at.z + x.z * shake);
        Matrix4f basis = new Matrix4f((float) x.x, (float) x.y, (float) x.z, 0, 0, 1, 0, 0, (float) z.x, (float) z.y, (float) z.z, 0, 0, 0, 0, 1);
        ps.last().pose().mul(basis);
        ps.last().normal().mul(new Matrix3f(basis));
        VertexConsumer vc = c.buffers().getBuffer(RenderType.entityCutoutNoCull(COFFIN));
        int light = FxDraw.lightAt(at.add(0, 1.2, 0));
        JutsuMesh.draw(mesh.get(0), ps.last(), vc, 1f, 1f, 1f, 1f, light, OverlayTexture.NO_OVERLAY);
        // the lid: shut, then it tips forward and slams flat on the ground (with a small bounce)
        float t = Mth.clamp((age - EdoTensei.LID) / 9f, 0f, 1f);
        float angle = t * t * 92f;
        if (t >= 1f) angle = 92f - Math.abs(Mth.sin((age - EdoTensei.LID - 9) * 0.9f)) * 6f * Math.max(0f, 1f - (age - EdoTensei.LID - 9) / 6f);
        ps.translate(0, HINGE_Y, HINGE_Z);
        ps.mulPose(Axis.XP.rotationDegrees(angle));
        JutsuMesh.draw(mesh.get(1), ps.last(), vc, 1f, 1f, 1f, 1f, light, OverlayTexture.NO_OVERLAY);
        ps.popPose();

        // dust kicked up where it breaks the surface, and where the lid lands
        VertexConsumer dust = FxDraw.lit(c.buffers());
        RandomSource r = FxDraw.rng(c.fx().seed, 31);
        double ground = at.y;
        if (age < EdoTensei.RISE + 8 || (age > sinkStart && age < c.fx().ticks)) {
            float a = age < EdoTensei.RISE + 8 ? 1f - Math.max(0f, (age - EdoTensei.RISE) / 8f) : 0.8f;
            for (int k = 0; k < 26; k++) {
                double ang = r.nextFloat() * Math.PI * 2, d = 0.55 + r.nextFloat() * 0.5 + (age % 10) * 0.02;
                Vec3 p = new Vec3(at.x + Math.cos(ang) * d, ground + 0.05 + r.nextFloat() * 0.3, at.z + Math.sin(ang) * d);
                FxDraw.billboard(dust, c.ps(), c.camera(), p, 0.09f, 0.09f, r.nextFloat() * 6 + age * 0.3f,
                        FxDraw.color(k % 3 == 0 ? ASH_DARK : 0x7A6550, 0.85f * a), light);
            }
        }
        if (t >= 1f && age < EdoTensei.LID + 22) {
            float a = 1f - (age - EdoTensei.LID - 9) / 13f;
            Vec3 land = at.add(face.scale(HINGE_Z + 1.1));
            for (int k = 0; k < 30; k++) {
                double ang = r.nextFloat() * Math.PI * 2, d = 0.4 + r.nextFloat() * 1.2 * (1.2f - a);
                Vec3 p = new Vec3(land.x + Math.cos(ang) * d, ground + 0.05 + r.nextFloat() * 0.35 * (1.2f - a), land.z + Math.sin(ang) * d);
                FxDraw.billboard(dust, c.ps(), c.camera(), p, 0.12f, 0.12f, r.nextFloat() * 6, FxDraw.color(0x8A7A66, 0.7f * a), light);
            }
        }
    }

    // ---------------------------------------------------------------- the sacrifice

    /** The sacrifice (entityA) wrapped in flakes of dust: they swirl in round it and pile on until nothing shows. */
    static void sacrifice(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 base = e.getPosition(c.partial());
        float w = Math.max(0.4f, e.getBbWidth()), h = e.getBbHeight();
        float p = Mth.clamp(c.age() / c.fx().ticks, 0f, 1f);
        VertexConsumer vc = FxDraw.lit(c.buffers());
        RandomSource r = FxDraw.rng(c.fx().seed, 7);
        int light = FxDraw.lightAt(base.add(0, h / 2, 0));
        int n = 40 + Math.round(240 * p);
        for (int k = 0; k < 280; k++) {
            float born = r.nextFloat();
            double ang = r.nextFloat() * Math.PI * 2, fy = r.nextFloat();
            float size = 0.07f + r.nextFloat() * 0.08f;
            int col = r.nextInt(5) == 0 ? PAPER : r.nextInt(3) == 0 ? ASH_DARK : ASH;
            if (k >= n) continue;
            // each flake spirals in from a wide orbit and settles on the body
            float settle = Mth.clamp((p - born * 0.6f) / 0.4f, 0f, 1f);
            double radius = w * 0.55 + (1f - FxDraw.smooth(settle)) * (1.2 + r.nextFloat());
            double spin = ang + (1f - settle) * 3.0 + c.age() * 0.02;
            Vec3 at = base.add(Math.cos(spin) * radius, fy * h * (0.4 + 0.6 * settle) + (1f - settle) * 0.4, Math.sin(spin) * radius);
            FxDraw.billboard(vc, c.ps(), c.camera(), at, size, size, (float) ang + c.age() * 0.2f * (1f - settle), FxDraw.color(col, 0.95f), light);
        }
    }

    /** The sacrifice's dust streaming (a to b) to where the coffin will come up, in a low arc. */
    static void dust(FxClient.Ctx c) {
        Vec3 from = c.fx().a, to = c.fx().b;
        float p = Mth.clamp(c.age() / (c.fx().ticks - 6f), 0f, 1.3f);
        VertexConsumer vc = FxDraw.lit(c.buffers());
        RandomSource r = FxDraw.rng(c.fx().seed, 11);
        int light = FxDraw.lightAt(to);
        Vec3 side = FxDraw.perpendicular(to.subtract(from).normalize());
        for (int k = 0; k < 160; k++) {
            float lag = r.nextFloat() * 0.5f;
            float t = Mth.clamp(p - lag, 0f, 1f);
            if (p - lag < 0f) continue;
            float spread = (1f - t) * 0.35f + 0.05f;
            double wob = r.nextFloat() * Math.PI * 2 + c.age() * 0.4;
            Vec3 at = from.lerp(to, t).add(0, Math.sin(t * Math.PI) * 1.2, 0)
                    .add(side.scale(Math.cos(wob) * spread)).add(0, Math.sin(wob) * spread, 0);
            float fade = t >= 1f ? Math.max(0f, 1f - (p - 1f) / 0.3f) : 1f;
            int col = r.nextInt(5) == 0 ? PAPER : r.nextInt(3) == 0 ? ASH_DARK : ASH;
            float s = 0.06f + r.nextFloat() * 0.07f;
            FxDraw.billboard(vc, c.ps(), c.camera(), at, s, s, (float) wob, FxDraw.color(col, 0.95f * fade), light);
        }
    }

    // ---------------------------------------------------------------- breaking apart, and the release

    /** A reanimated body (entityA) broken apart: flakes burst off it, hang, then drift back and seal the cracks. */
    static void crumble(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 base = e.getPosition(c.partial());
        float h = e.getBbHeight(), w = e.getBbWidth();
        float p = Mth.clamp(c.age() / c.fx().ticks, 0f, 1f);
        // out fast, hang a moment, then back in
        float out = p < 0.2f ? FxDraw.smooth(p / 0.2f) : p < 0.45f ? 1f : 1f - FxDraw.smooth((p - 0.45f) / 0.55f);
        VertexConsumer vc = FxDraw.lit(c.buffers());
        RandomSource r = FxDraw.rng(c.fx().seed, 23);
        int light = FxDraw.lightAt(base.add(0, h / 2, 0));
        for (int k = 0; k < 200; k++) {
            Vec3 home = base.add((r.nextFloat() - 0.5) * w, r.nextFloat() * h, (r.nextFloat() - 0.5) * w);
            Vec3 dir = new Vec3(r.nextFloat() - 0.5, r.nextFloat() * 0.6 - 0.15, r.nextFloat() - 0.5).normalize();
            double dist = 0.6 + r.nextFloat() * 1.6;
            double swirl = (1f - out) * 0.0 + out * Mth.sin(c.age() * 0.15f + k) * 0.15;
            Vec3 at = home.add(dir.scale(dist * out)).add(0, swirl, 0);
            float s = 0.06f + r.nextFloat() * 0.09f;
            int col = r.nextInt(4) == 0 ? PAPER : r.nextInt(3) == 0 ? ASH_DARK : ASH;
            float a = 0.95f * Math.min(1f, out * 3f);
            if (a <= 0.02f) continue;
            FxDraw.billboard(vc, c.ps(), c.camera(), at, s, s, k + c.age() * 0.25f * out, FxDraw.color(col, a), light);
        }
    }

    /** The soul released (a = where it stood, size = its height): a pale light goes up as the body falls away to dust. */
    static void release(FxClient.Ctx c) {
        Vec3 base = c.fx().a;
        float h = c.fx().size;
        float p = Mth.clamp(c.age() / c.fx().ticks, 0f, 1f);
        // the soul: a soft column of light rising and thinning out
        VertexConsumer glow = FxDraw.additive(c.buffers());
        float a = (p < 0.15f ? p / 0.15f : 1f - (p - 0.15f) / 0.85f) * 0.5f;
        for (int k = 0; k < 6; k++) {
            float y0 = p * 6f + k * 0.9f, y1 = y0 + 1.4f;
            float rad = 0.35f * (1f - k / 7f);
            FxDraw.tube(glow, c.ps(), List.of(base.add(0, y0, 0), base.add(0, y1, 0)), new float[]{rad, rad * 0.6f}, 12,
                    FxDraw.addColor(0xE8F0FF, a * (1f - k / 6f)), 1f, FxDraw.FULL, false);
        }
        // the body's dust: flakes falling away from where it stood into a little heap that blows away
        VertexConsumer vc = FxDraw.lit(c.buffers());
        RandomSource r = FxDraw.rng(c.fx().seed, 41);
        int light = FxDraw.lightAt(base.add(0, 1, 0));
        for (int k = 0; k < 220; k++) {
            Vec3 from = base.add((r.nextFloat() - 0.5) * 0.6, r.nextFloat() * h, (r.nextFloat() - 0.5) * 0.6);
            float delay = (float) (1.0 - (from.y - base.y) / h) * 0.35f;     // the head goes first
            float t = Mth.clamp((p - delay) / 0.45f, 0f, 1f);
            if (t <= 0f) {
                continue;
            }
            Vec3 drift = new Vec3((r.nextFloat() - 0.5) * 1.6, 0, (r.nextFloat() - 0.5) * 1.6);
            double y = Mth.lerp(t * t, (float) from.y, (float) base.y + 0.05f);
            Vec3 at = new Vec3(from.x + drift.x * t, y, from.z + drift.z * t);
            float fade = 1f - Mth.clamp((p - 0.75f) / 0.25f, 0f, 1f);
            float s = 0.06f + r.nextFloat() * 0.08f;
            int col = r.nextInt(3) == 0 ? ASH_DARK : ASH;
            FxDraw.billboard(vc, c.ps(), c.camera(), at, s, s, k + t * 4, FxDraw.color(col, 0.9f * fade), light);
        }
    }
}
