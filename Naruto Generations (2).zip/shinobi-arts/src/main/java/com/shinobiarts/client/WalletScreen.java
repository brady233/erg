package com.shinobiarts.client;

import com.shinobiarts.item.CoinItem;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * The Frog Wallet screen is the frog itself: a big green face with white eyes whose mouth opens to show
 * your Ryo and the coin buttons inside. The tongue closes it. There are no item slots, so only Ryo can go in,
 * and every deposit/withdrawal is done (and checked) on the server.
 */
public class WalletScreen extends Screen {
    // Design size in GUI pixels; everything scales down together on small screens.
    private static final int FACE_W = 300;
    private static final int FACE_H = 214;
    private static final int EYE_RISE = 22;
    private static final int MOUTH_W = 254;
    private static final int MOUTH_H = 156;
    private static final long OPEN_MS = 380;

    private static final int GREEN = 0xFF2F9A1E;
    private static final int GREEN_LIGHT = 0xFF57C23C;
    private static final int GREEN_DARK = 0xFF145A0B;
    private static final int MOUTH = 0xFF0A0A0A;
    private static final int TONGUE = 0xFFE01E1E;
    private static final int TONGUE_LIGHT = 0xFFFF5A5A;

    private final Map<CoinItem.Coin, Button[]> coinButtons = new EnumMap<>(CoinItem.Coin.class);
    private final List<Button> mouthButtons = new ArrayList<>();
    private Button depositAll;
    private Button tongue;
    private long openedAt;
    private float s;      // layout scale
    private int cx;       // face center x
    private int faceTop;  // top of the green face

    public WalletScreen() {
        super(Component.translatable("screen.shinobiarts.wallet"));
    }

    private int sc(float v) {
        return Math.round(v * s);
    }

    @Override
    protected void init() {
        openedAt = System.currentTimeMillis();
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.FROG_AMBIENT, 1.2f));
        s = Mth.clamp((this.height - 16) / (float) (FACE_H + EYE_RISE + 14), 0.6f, 1.0f);
        s = Math.min(s, (this.width - 16) / (float) FACE_W);
        cx = this.width / 2;
        faceTop = (this.height - sc(FACE_H + EYE_RISE + 14)) / 2 + sc(EYE_RISE);

        mouthButtons.clear();
        coinButtons.clear();
        int rowLeft = cx - sc(94);
        int firstRow = mouthTop() + sc(42);
        for (CoinItem.Coin coin : CoinItem.Coin.values()) {
            int y = firstRow + coin.ordinal() * sc(24);
            Button deposit = addRenderableWidget(new FrogButton(rowLeft + sc(96), y, sc(44), sc(16),
                    Component.translatable("screen.shinobiarts.deposit"),
                    b -> ModNetwork.toServer(new ActionPacket(ActionPacket.DEPOSIT, coin.ordinal(), 0))));
            Button one = addRenderableWidget(new FrogButton(rowLeft + sc(143), y, sc(20), sc(16), Component.literal("-1"),
                    b -> ModNetwork.toServer(new ActionPacket(ActionPacket.WITHDRAW, coin.ordinal(), 1))));
            Button ten = addRenderableWidget(new FrogButton(rowLeft + sc(165), y, sc(24), sc(16), Component.literal("-10"),
                    b -> ModNetwork.toServer(new ActionPacket(ActionPacket.WITHDRAW, coin.ordinal(), 10))));
            coinButtons.put(coin, new Button[]{deposit, one, ten});
            mouthButtons.add(deposit);
            mouthButtons.add(one);
            mouthButtons.add(ten);
        }
        depositAll = addRenderableWidget(new FrogButton(cx - sc(55), firstRow + 3 * sc(24) + sc(2), sc(110), sc(16),
                Component.translatable("screen.shinobiarts.deposit_all"),
                b -> ModNetwork.toServer(new ActionPacket(ActionPacket.DEPOSIT, -1, 0))));
        mouthButtons.add(depositAll);

        // The tongue is the close button.
        int tongueW = sc(64), tongueH = sc(24);
        tongue = addRenderableWidget(new TongueButton(cx - tongueW / 2, mouthTop() + sc(MOUTH_H) - sc(14), tongueW, tongueH,
                Component.translatable("screen.shinobiarts.close"), b -> onClose()));
        tick();
    }

    private int mouthTop() {
        return faceTop + sc(FACE_H) / 2 - sc(MOUTH_H) / 2 + sc(10);
    }

    private float openProgress(float partialTick) {
        float t = Mth.clamp((System.currentTimeMillis() - openedAt) / (float) OPEN_MS, 0f, 1f);
        return 1f - (1f - t) * (1f - t) * (1f - t); // ease-out
    }

    private int countInInventory(CoinItem.Coin coin) {
        if (this.minecraft == null || this.minecraft.player == null) return 0;
        Inventory inv = this.minecraft.player.getInventory();
        int count = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.getItem() instanceof CoinItem c && c.coin() == coin) count += stack.getCount();
        }
        return count;
    }

    @Override
    public void tick() {
        NinjaData d = ClientNinjaData.get();
        boolean any = false;
        for (CoinItem.Coin coin : CoinItem.Coin.values()) {
            Button[] b = coinButtons.get(coin);
            if (b == null) continue;
            int have = countInInventory(coin);
            any |= have > 0;
            b[0].active = have > 0;
            b[1].active = d.getRyo() >= coin.value();
            b[2].active = d.getRyo() >= coin.value() * 10L;
        }
        if (depositAll != null) depositAll.active = any;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        float open = openProgress(partialTick);
        for (Button b : mouthButtons) b.visible = open > 0.92f;
        tongue.visible = open > 0.75f;

        drawFace(g);
        drawEyes(g);
        int mouthH = Math.max(sc(6), Math.round(sc(MOUTH_H) * open));
        int mouthW = Math.round(sc(MOUTH_W) * (0.55f + 0.45f * open));
        int mouthCenterY = mouthTop() + sc(MOUTH_H) / 2;
        fillEllipse(g, cx, mouthCenterY, mouthW / 2f + sc(4), mouthH / 2f + sc(4), GREEN_DARK);
        fillEllipse(g, cx, mouthCenterY, mouthW / 2f, mouthH / 2f, MOUTH);

        if (open > 0.6f) drawMouthContents(g, open);
        super.render(g, mouseX, mouseY, partialTick);
    }

    private void drawFace(GuiGraphics g) {
        int cy = faceTop + sc(FACE_H) / 2;
        float rx = sc(FACE_W) / 2f, ry = sc(FACE_H) / 2f;
        fillEllipse(g, cx, cy, rx + sc(4), ry + sc(4), GREEN_DARK);
        fillEllipse(g, cx, cy, rx, ry, GREEN);
        // soft highlight on the upper left
        fillEllipse(g, cx - sc(60), cy - sc(62), sc(70), sc(28), GREEN_LIGHT & 0x70FFFFFF);
        // cheeks
        fillEllipse(g, cx - sc(118), cy + sc(30), sc(16), sc(10), 0x50FF8A8A);
        fillEllipse(g, cx + sc(118), cy + sc(30), sc(16), sc(10), 0x50FF8A8A);
    }

    private void drawEyes(GuiGraphics g) {
        int eyeY = faceTop - sc(EYE_RISE);
        for (int side = -1; side <= 1; side += 2) {
            int ex = cx + side * sc(78);
            fillEllipse(g, ex, eyeY + sc(22), sc(32), sc(26), GREEN_DARK);
            fillEllipse(g, ex, eyeY + sc(22), sc(28), sc(22), GREEN);
            fillEllipse(g, ex, eyeY + sc(18), sc(20), sc(16), 0xFF101010);
            fillEllipse(g, ex, eyeY + sc(18), sc(18), sc(14), 0xFFFFFFFF);
            g.fill(ex - sc(3), eyeY + sc(6), ex + sc(3), eyeY + sc(22), 0xFF101010); // pupil, like the item sprite
        }
    }

    private void drawMouthContents(GuiGraphics g, float open) {
        float alpha = Mth.clamp((open - 0.6f) / 0.4f, 0f, 1f);
        int a = Math.max(8, Math.round(alpha * 255)) << 24; // fonts treat alpha 0 as opaque
        Font font = this.font;
        NinjaData d = ClientNinjaData.get();
        int top = mouthTop();

        // Balance
        String balance = PlayerDataManager.formatRyo(d.getRyo()) + " Ryo";
        float bs = 1.4f * s;
        int bw = Math.round(font.width(balance) * bs);
        int bx = cx - (bw + sc(20)) / 2;
        g.renderItem(new ItemStack(ModItems.coin(CoinItem.Coin.GOLD)), bx, top + sc(14));
        g.pose().pushPose();
        g.pose().translate(bx + sc(20), top + sc(17), 0);
        g.pose().scale(bs, bs, 1f);
        g.drawString(font, balance, 0, 0, a | 0xF2C230, true);
        g.pose().popPose();

        // Coin rows: icon, name, how many you're carrying
        int rowLeft = cx - sc(94);
        int firstRow = top + sc(42);
        for (CoinItem.Coin coin : CoinItem.Coin.values()) {
            int y = firstRow + coin.ordinal() * sc(24);
            g.renderItem(new ItemStack(ModItems.coin(coin)), rowLeft, y);
            float ts = 0.75f * s;
            g.pose().pushPose();
            g.pose().translate(rowLeft + sc(19), y + sc(1), 0);
            g.pose().scale(ts, ts, 1f);
            g.drawString(font, Component.translatable("item.shinobiarts." + coin.id() + "_ryo"), 0, 0, a | coin.rgb(), true);
            g.drawString(font, Component.translatable("screen.shinobiarts.coin_row", countInInventory(coin),
                    PlayerDataManager.formatRyo(coin.value())), 0, 11, a | 0xA0A0A0, false);
            g.pose().popPose();
        }
    }

    /** Filled ellipse drawn as horizontal strips, 2px tall for a crisp pixel-art look. */
    private static void fillEllipse(GuiGraphics g, float cx, float cy, float rx, float ry, int color) {
        if (rx <= 0 || ry <= 0) return;
        for (float dy = -ry; dy < ry; dy += 2) {
            float t = (dy + 1) / ry;
            float half = rx * (float) Math.sqrt(Math.max(0, 1 - t * t));
            if (half < 0.5f) continue;
            g.fill(Math.round(cx - half), Math.round(cy + dy), Math.round(cx + half), Math.round(cy + dy + 2), color);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** A small flat green button that fits the frog's mouth. */
    static class FrogButton extends Button {
        FrogButton(int x, int y, int w, int h, Component message, OnPress onPress) {
            super(x, y, w, h, message, onPress, DEFAULT_NARRATION);
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            int x = getX(), y = getY();
            int bg = !this.active ? 0xFF262626 : isHoveredOrFocused() ? 0xFF4CAF50 : 0xFF2E7D32;
            g.fill(x, y, x + width, y + height, this.active ? 0xFF0B2E0B : 0xFF151515);
            g.fill(x + 1, y + 1, x + width - 1, y + height - 1, bg);
            if (this.active) g.fill(x + 1, y + 1, x + width - 1, y + 2, 0x40FFFFFF);
            Font font = Minecraft.getInstance().font;
            int color = this.active ? 0xFFFFFFFF : 0xFF6A6A6A;
            float ts = Math.min(1f, (height - 4) / 8f);
            g.pose().pushPose();
            g.pose().translate(x + width / 2f - font.width(getMessage()) * ts / 2f, y + (height - 8 * ts) / 2f + 0.5f, 0);
            g.pose().scale(ts, ts, 1f);
            g.drawString(font, getMessage(), 0, 0, color, true);
            g.pose().popPose();
        }
    }

    /** The frog's tongue, which closes the wallet. */
    static class TongueButton extends Button {
        TongueButton(int x, int y, int w, int h, Component message, OnPress onPress) {
            super(x, y, w, h, message, onPress, DEFAULT_NARRATION);
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            float cx = getX() + width / 2f, cy = getY() + height / 2f;
            int color = isHoveredOrFocused() ? TONGUE_LIGHT : TONGUE;
            fillEllipse(g, cx, cy, width / 2f + 2, height / 2f + 2, 0xFF6A0A0A);
            fillEllipse(g, cx, cy, width / 2f, height / 2f, color);
            g.fill(Math.round(cx) - 1, getY() + 3, Math.round(cx) + 1, getY() + height / 2, 0x60000000); // tongue crease
            Font font = Minecraft.getInstance().font;
            g.drawString(font, getMessage(), Math.round(cx - font.width(getMessage()) / 2f), Math.round(cy - 3), 0xFFFFFFFF, true);
        }
    }
}
