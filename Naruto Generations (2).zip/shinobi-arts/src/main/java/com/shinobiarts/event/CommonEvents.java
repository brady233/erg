package com.shinobiarts.event;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.command.ShinobiCommand;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.jutsu.JutsuEffects;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.jutsu.NinjaTicker;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.DojutsuSlot;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.NinjaDataProvider;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.Stat;
import com.shinobiarts.registry.ModDamage;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CommonEvents {
    private static final ResourceLocation NINJA_DATA_ID = ShinobiArts.id("ninja_data");

    private CommonEvents() {}

    // ---------------------------------------------------------------- player data lifecycle

    /** Releases can't be thrown away (they can still go in chests): a toss puts it straight back in the inventory. */
    @SubscribeEvent
    public static void onToss(net.minecraftforge.event.entity.item.ItemTossEvent event) {
        net.minecraft.world.item.ItemStack stack = event.getEntity().getItem();
        if (!(stack.getItem() instanceof com.shinobiarts.item.ReleaseItem)) return;
        event.setCanceled(true);
        net.minecraft.world.entity.player.Player player = event.getPlayer();
        if (!player.getInventory().add(stack.copy())) {
            event.setCanceled(false);                                  // nowhere to put it: let it drop after all
            return;
        }
        player.displayClientMessage(Component.translatable("message.shinobiarts.release_no_drop").withStyle(ChatFormatting.RED), true);
    }

    @SubscribeEvent
    public static void attachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            // No invalidate listener on purpose: when a player dies, Forge invalidates the old body's capabilities
            // before the Clone event runs. With a listener that invalidation was permanent, so reviveCaps() could
            // not bring the data back, the respawned player started blank and the whole HUD disappeared.
            event.addCapability(NINJA_DATA_ID, new NinjaDataProvider());
        }
    }

    /** Copies data to the new player object after death or returning from the End. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        Player original = event.getOriginal();
        original.reviveCaps();
        NinjaData oldData = NinjaData.get(original);
        NinjaData newData = NinjaData.get(event.getEntity());
        if (oldData != null && newData != null) {
            newData.load(oldData.save());
            if (event.isWasDeath()) {
                newData.resetStates();
                newData.setChakra(newData.maxChakra());
            }
        } else {
            ShinobiArts.LOGGER.error("Could not copy ninja data for {} (old: {}, new: {})",
                    event.getEntity().getName().getString(), oldData != null, newData != null);
        }
        original.invalidateCaps();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        if (!data.isInitialized()) {
            data.init(player.getRandom());
            welcome(player, data);
            ReleaseItem.give(player, ChakraNature.NONE); // the starter release, empty until jutsu are learned
            giveStarterKit(player);
        }
        data.setCharging(false);
        data.clearCombat(); // anyone who logged out in combat was already killed for it
        // Kamui is held: nobody is holding the key after logging back in (this also frees anyone left inside a wall)
        if (data.getIntangibleUntil() != 0 || data.kamuiGaveFlight()) com.shinobiarts.ninja.EyeTechniques.endIntangible(player, data);
        // the Susanoo isn't saved: set a Perfect Susanoo's rider back down and give back their flight setting
        if (data.getSusanooStage() > 0 || data.susanooGaveFlight()) com.shinobiarts.ninja.Susanoo.endQuietly(player);
        if (data.getGatesOpen() > 0) {          // the gates' boosts don't survive logging out
            data.setGatesOpen(0);
            data.setGate8Until(0);
        }
        DojutsuSlot.addTo(player);
        moveSharinganToDojutsuSlot(player, data);
        com.shinobiarts.village.VillageManager.refresh(player);
        com.shinobiarts.village.VillageManager.refreshTitles(player);
        PlayerDataManager.applyStatEffects(player);
        ModNetwork.sync(player);
        SharinganManager.checkEvolution(player);
        SharinganManager.broadcastEyes(player);
        com.shinobiarts.team.TeamManager.get(player.server).onLogin(player);
    }

    /** The Sharingan used to be a helmet: one still worn on the head moves to the dojutsu slot (or the inventory). */
    private static void moveSharinganToDojutsuSlot(ServerPlayer player, NinjaData data) {
        ItemStack head = player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD);
        if (!(head.getItem() instanceof com.shinobiarts.item.SharinganItem)) return;
        player.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, ItemStack.EMPTY);
        if (data.getDojutsuItem().isEmpty()) {
            data.setDojutsuItem(head.copyWithCount(1));
        } else if (!player.getInventory().add(head)) {
            player.drop(head, false);
        }
        player.inventoryMenu.broadcastChanges();
    }

    /** Adds the dojutsu slot to a player's inventory as they enter a world (on the server and on the client). */
    @SubscribeEvent
    public static void onJoinLevel(net.minecraftforge.event.entity.EntityJoinLevelEvent event) {
        if (event.getEntity() instanceof Player player) DojutsuSlot.addTo(player);
    }

    /** What's in the dojutsu slot drops on death like armor does (unless keepInventory is on). */
    @SubscribeEvent
    public static void onPlayerDrops(net.minecraftforge.event.entity.living.LivingDropsEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.level().getGameRules().getBoolean(net.minecraft.world.level.GameRules.RULE_KEEPINVENTORY)) return;
        NinjaData data = NinjaData.get(player);
        if (data == null || data.getDojutsuItem().isEmpty()) return;
        ItemStack stack = data.getDojutsuItem();
        data.setDojutsuItem(ItemStack.EMPTY);
        if (com.shinobiarts.item.ActiveEyeItem.is(stack)) return; // switched-on eyes aren't an item: they just go out
        event.getDrops().add(new net.minecraft.world.entity.item.ItemEntity(player.level(), player.getX(), player.getY(), player.getZ(), stack));
    }

    /** Amaterasu is no longer a jutsu scroll: old Amaterasu scrolls turn back into blank scrolls. */
    @SubscribeEvent
    public static void onMissingMappings(net.minecraftforge.registries.MissingMappingsEvent event) {
        for (net.minecraftforge.registries.MissingMappingsEvent.Mapping<net.minecraft.world.item.Item> mapping
                : event.getMappings(net.minecraftforge.registries.ForgeRegistries.Keys.ITEMS, ShinobiArts.MODID)) {
            if (mapping.getKey().getPath().equals("scroll_amaterasu")) mapping.remap(com.shinobiarts.registry.ModItems.BLANK_SCROLL.get());
        }
    }

    /** Every new ninja starts with a Frog Wallet and 3 kunai. */
    private static void giveStarterKit(ServerPlayer player) {
        for (ItemStack stack : new ItemStack[]{new ItemStack(com.shinobiarts.registry.ModItems.FROG_WALLET.get()),
                new ItemStack(com.shinobiarts.registry.ModItems.KUNAI.get(), 3)}) {
            player.getInventory().add(stack);
            if (!stack.isEmpty()) player.drop(stack, false);
        }
        player.sendSystemMessage(Component.translatable("message.shinobiarts.starter_kit").withStyle(ChatFormatting.AQUA));
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            com.shinobiarts.ninja.Susanoo.endQuietly(player);
            com.shinobiarts.jutsu.ShadowPossession.end(player);
            com.shinobiarts.jutsu.WaterPrison.end(player, false);
            com.shinobiarts.jutsu.MindTransfer.end(player);
            com.shinobiarts.jutsu.MindTransfer.end(player);
            com.shinobiarts.team.TeamManager.get(player.server).onLogout(player);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(net.minecraftforge.event.server.ServerStoppedEvent event) {
        com.shinobiarts.ninja.Susanoo.clearAll();
        com.shinobiarts.jutsu.ShadowPossession.clearAll();
        com.shinobiarts.jutsu.WaterPrison.clearAll();
        com.shinobiarts.jutsu.MindTransfer.clearAll();
    }

    /** When a player comes into view, tell the viewer whether that player's Sharingan is on. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getEntity() instanceof ServerPlayer viewer && event.getTarget() instanceof ServerPlayer target) {
            SharinganManager.sendEyes(viewer, target);
        }
    }

    /**
     * Tells a player which clan they rolled, its rarity and every bonus it gives. Rare and Mythic rolls are announced
     * to the whole server (config: announceRareClans).
     */
    public static void announceClan(ServerPlayer player, NinjaData data, boolean broadcast) {
        Clan clan = data.getClan();
        player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_result", clan.displayName(), clan.rarityText())
                .withStyle(ChatFormatting.GOLD));
        for (Component line : clan.describe()) {
            player.sendSystemMessage(Component.literal(" - ").withStyle(ChatFormatting.DARK_GRAY).append(line));
        }
        boolean rare = clan.rarity() == Clan.Rarity.RARE || clan.rarity() == Clan.Rarity.MYTHIC;
        if (broadcast && rare && Config.b(Config.ANNOUNCE_RARE_CLANS)) {
            boolean mythic = clan.rarity() == Clan.Rarity.MYTHIC;
            Component msg = Component.translatable(mythic ? "message.shinobiarts.clan_born_mythic" : "message.shinobiarts.clan_born",
                    player.getDisplayName(), clan.displayName(), clan.rarity().displayName()).withStyle(mythic ? ChatFormatting.GOLD : ChatFormatting.AQUA);
            for (ServerPlayer p : player.server.getPlayerList().getPlayers()) {
                p.sendSystemMessage(msg);
                if (mythic) p.playNotifySound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, net.minecraft.sounds.SoundSource.PLAYERS, 1.0f, 0.8f);
            }
        }
    }

    /** "Roll your clan with /clanroll!" with a clickable button. */
    public static void clanRollIntro(ServerPlayer player) {
        player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_intro", Config.i(Config.CLAN_ROLLS))
                .withStyle(ChatFormatting.GOLD)
                .append(com.shinobiarts.command.ClanCommand.button("message.shinobiarts.clanroll_intro_button", "/clanroll", ChatFormatting.AQUA)));
    }

    private static void welcome(ServerPlayer player, NinjaData data) {
        clanRollIntro(player);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.paper").withStyle(ChatFormatting.YELLOW));
        player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.keys").withStyle(ChatFormatting.YELLOW));
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            com.shinobiarts.jutsu.ShadowPossession.end(player);   // dying lets go of whatever the shadow held
            com.shinobiarts.jutsu.WaterPrison.end(player, false);
            PlayerDataManager.applyStatEffects(player);
            if (!event.isEndConquered()) player.setHealth(player.getMaxHealth());
            ModNetwork.sync(player);
            SharinganManager.broadcastEyes(player); // dying turns the Sharingan off; clear it from everyone's view
        }
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            com.shinobiarts.ninja.Susanoo.endQuietly(player);
            ModNetwork.sync(player);
        }
    }

    /**
     * Kamui: an intangible player has no collision, so they fly through blocks. Player.tick() resets noPhysics each
     * tick before this event, and movement comes after it, so it's set here (the client does the same for itself).
     */
    @SubscribeEvent
    public static void onLivingTick(net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data != null && data.isIntangible(player.level().getGameTime())) player.noPhysics = true;
    }

    /** Clans immune to poison (Aburame, Kamizuru) never get it. */
    @SubscribeEvent
    public static void onEffectApplicable(net.minecraftforge.event.entity.living.MobEffectEvent.Applicable event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getEffectInstance().getEffect() != MobEffects.POISON) return;
        NinjaData data = NinjaData.get(player);
        if (data != null && data.getClan().buffs().poisonImmune()) event.setResult(net.minecraftforge.eventbus.api.Event.Result.DENY);
    }

    /** Someone frozen by Tsukuyomi (or any stun) can't attack. */
    @SubscribeEvent
    public static void onAttackedByStunned(LivingAttackEvent event) {
        if (event.getSource().getEntity() instanceof LivingEntity attacker && attacker != event.getEntity()
                && com.shinobiarts.ninja.Afflictions.isStunned(attacker)) {
            event.setCanceled(true);
        }
    }

    /** Kamui: arrows, fireballs and jutsu projectiles fly straight through an intangible player. */
    @SubscribeEvent
    public static void onProjectileImpact(net.minecraftforge.event.entity.ProjectileImpactEvent event) {
        if (!(event.getRayTraceResult() instanceof net.minecraft.world.phys.EntityHitResult hit)) return;
        // your own arrows and jutsu fly out through your own Susanoo
        if (hit.getEntity() instanceof com.shinobiarts.entity.SusanooEntity susanoo && event.getProjectile().getOwner() != null
                && event.getProjectile().getOwner().getId() == susanoo.getOwnerId()) {
            if (event.isCancelable()) event.setCanceled(true);
            return;
        }
        if (!(hit.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data != null && data.isIntangible(player.level().getGameTime()) && event.isCancelable()) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.side == LogicalSide.SERVER && event.player instanceof ServerPlayer player) {
            NinjaTicker.tick(player);
        }
    }

    @SubscribeEvent
    public static void registerCommands(RegisterCommandsEvent event) {
        ShinobiCommand.register(event.getDispatcher());
        com.shinobiarts.command.TeamCommand.register(event.getDispatcher());
        com.shinobiarts.command.VillageCommand.register(event.getDispatcher());
        com.shinobiarts.command.ClanCommand.register(event.getDispatcher());
        com.shinobiarts.command.SusanooCommand.register(event.getDispatcher());
        com.shinobiarts.command.ShopCommand.register(event.getDispatcher());
        com.shinobiarts.command.JinchurikiCommand.register(event.getDispatcher());
        com.shinobiarts.command.BountyCommand.register(event.getDispatcher());
    }

    // ---------------------------------------------------------------- combat

    /** Kamui: an intangible player can't be hurt by anything (but the void), and can't hurt anything either. */
    @SubscribeEvent(priority = net.minecraftforge.eventbus.api.EventPriority.HIGH)
    public static void onAttackedIntangible(LivingAttackEvent event) {
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return;
        if (event.getEntity() instanceof ServerPlayer victim) {
            NinjaData vd = NinjaData.get(victim);
            if (vd != null && vd.isIntangible(victim.level().getGameTime())) {
                event.setCanceled(true);
                return;
            }
        }
        if (source.getEntity() instanceof ServerPlayer attacker && source.getEntity() != event.getEntity()) {
            NinjaData ad = NinjaData.get(attacker);
            if (ad != null && ad.isIntangible(attacker.level().getGameTime())) event.setCanceled(true);
        }
    }

    /** Defensive techniques: Palm Rotation, Substitution and the Sharingan's dodge. */
    @SubscribeEvent
    public static void onAttacked(LivingAttackEvent event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player)) return;
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.getEntity() == null || source.getEntity() == player) return;
        if (source.is(ModDamage.KAMUI)) return; // space-time: no dodging or substituting out of a Kamui snap
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        long now = player.level().getGameTime();

        if (data.getRotationUntil() > now) {
            event.setCanceled(true);
            return;
        }
        if (data.getSusanooStage() > 0) return; // the Susanoo takes the hit (onAttackedSusanoo), no dodging out of it
        if (com.shinobiarts.jutsu.JutsuEffects.autoSubstitute(player, data, now)) {
            event.setCanceled(true);
            JutsuEffects.triggerSubstitution(player, source.getEntity());
            ModNetwork.sync(player);
            return;
        }
        if (data.isSharinganActive()) {
            float chance = SharinganManager.dodgeChance(data.activeSharinganStage(), data.genjutsuMultiplier());
            if (player.getRandom().nextFloat() < chance) {
                event.setCanceled(true);
                player.serverLevel().sendParticles(ParticleTypes.CRIT, player.getX(), player.getY() + 1, player.getZ(), 10, 0.3, 0.5, 0.3, 0.1);
                JutsuUtil.sound(player.level(), player.position(), SoundEvents.PLAYER_ATTACK_NODAMAGE, 1.0f, 1.4f);
                player.displayClientMessage(Component.translatable("message.shinobiarts.dodged").withStyle(ChatFormatting.RED), true);
            }
        }
        // clan evasion: Iburi smoke, Hozuki water body, Otsutsuki...
        float dodge = data.getClan().buffs().dodge();
        if (!event.isCanceled() && dodge > 0 && player.getRandom().nextFloat() < dodge) {
            event.setCanceled(true);
            player.serverLevel().sendParticles(ParticleTypes.POOF, player.getX(), player.getY() + 1, player.getZ(), 12, 0.3, 0.5, 0.3, 0.02);
            JutsuUtil.sound(player.level(), player.position(), SoundEvents.PLAYER_ATTACK_NODAMAGE, 1.0f, 1.2f);
            player.displayClientMessage(Component.translatable("message.shinobiarts.clan_dodged").withStyle(ChatFormatting.AQUA), true);
        }
    }

    /** Mind Body Transfer: the caster's own body feels what the body they've taken over suffers. */
    @SubscribeEvent(priority = net.minecraftforge.eventbus.api.EventPriority.LOWEST)
    public static void onBorrowedBodyHurt(LivingHurtEvent event) {
        if (event.getEntity().level().isClientSide || com.shinobiarts.jutsu.MindTransfer.casterInside(event.getEntity()) == null) return;
        com.shinobiarts.jutsu.MindTransfer.shareDamage(event.getEntity(), event.getAmount());
    }

    /** Clan defenses: less damage from projectiles (Kazekage sand) and from falls (Iburi smoke). */
    @SubscribeEvent
    public static void onPlayerHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        com.shinobiarts.ninja.ClanBuffs buffs = data.getClan().buffs();
        DamageSource source = event.getSource();
        if (buffs.projectileResist() > 0 && source.is(DamageTypeTags.IS_PROJECTILE)) {
            event.setAmount(event.getAmount() * (1f - buffs.projectileResist()));
        }
        if (buffs.fallResist() > 0 && source.is(DamageTypeTags.IS_FALL)) {
            event.setAmount(event.getAmount() * (1f - buffs.fallResist()));
        }
        float gates = com.shinobiarts.ninja.EightGates.resistance(data);
        if (gates > 0 && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) event.setAmount(event.getAmount() * (1f - gates));
    }

    /** Offensive bonuses: Taijutsu fists, Kenjutsu swords, Rasengan, Gentle Fist and Sage Mode jutsu. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        DamageSource source = event.getSource();
        if (!(source.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        LivingEntity target = event.getEntity();

        // Sage Mode empowers every jutsu.
        if (source.is(ModDamage.JUTSU) && data.isSageMode()) {
            event.setAmount(event.getAmount() * (1f + Config.f(Config.SAGE_MODE_JUTSU_BONUS)));
            return;
        }

        if (!source.is(DamageTypes.PLAYER_ATTACK) || source.getDirectEntity() != player) return;
        long now = player.level().getGameTime();
        boolean changed = false;

        ItemStack weapon = player.getMainHandItem();
        boolean fists = weapon.isEmpty() || weapon.getItem() instanceof ReleaseItem;
        if (fists) event.setAmount(event.getAmount() + com.shinobiarts.ninja.EightGates.punchBonus(data)); // open gates
        if (fists && data.stat(Stat.TAIJUTSU) > 0) {
            event.setAmount(event.getAmount() + data.stat(Stat.TAIJUTSU) * Config.f(Config.TAIJUTSU_PER_POINT));
        } else if (weapon.getItem() instanceof SwordItem && data.stat(Stat.KENJUTSU) > 0) {
            event.setAmount(event.getAmount() + data.stat(Stat.KENJUTSU) * Config.f(Config.KENJUTSU_PER_POINT));
        }

        // clan melee bonuses, chakra drain and on-hit effects
        com.shinobiarts.ninja.ClanBuffs buffs = data.getClan().buffs();
        float mult = 1f + buffs.melee() + (fists ? buffs.fist() : 0f) + (weapon.getItem() instanceof SwordItem ? buffs.sword() : 0f);
        if (mult != 1f) event.setAmount(event.getAmount() * mult);
        if (buffs.drainOnHit() > 0 && target instanceof ServerPlayer victim && victim != player) {
            float drained = PlayerDataManager.drainChakra(victim, buffs.drainOnHit());
            if (drained > 0) {
                data.addChakra(drained);
                changed = true;
            }
        }
        for (java.util.Map.Entry<com.shinobiarts.ninja.ClanBuffs.OnHit, Float> e : buffs.onHitEffects().entrySet()) {
            if (player.getRandom().nextFloat() < e.getValue()) {
                target.addEffect(new MobEffectInstance(e.getKey().effect(), e.getKey().ticks(), e.getKey().amplifier()), player);
            }
        }

        if (data.hasChidori(now)) {                                 // the Chidori in hand goes in
            event.setAmount(event.getAmount() + JutsuEffects.chidoriHit(player, target, data));
            com.shinobiarts.jutsu.JutsuUtil.noteCast(player, com.shinobiarts.jutsu.Jutsus.CHIDORI);
            changed = true;
        } else if (data.hasRasengan(now) && data.isRasenshuriken()) {     // slammed into it: it bursts right there
            float dmg = JutsuEffects.rasenshurikenDamage(data);
            event.setAmount(event.getAmount() + dmg);
            com.shinobiarts.jutsu.JutsuUtil.noteCast(player, com.shinobiarts.jutsu.Jutsus.RASENSHURIKEN);
            data.setRasenganUntil(0);
            com.shinobiarts.entity.JutsuProjectile.rasenshurikenBurst(player.serverLevel(), player, player,
                    target.getBoundingBox().getCenter(), dmg, target);
            com.shinobiarts.ninja.SharinganManager.updateLook(player);
            changed = true;
        } else if (data.hasRasengan(now)) {                        // only once it's formed
            event.setAmount(event.getAmount() + JutsuUtil.dmg(14f) * data.jutsuBonus(com.shinobiarts.jutsu.Jutsus.RASENGAN));
            data.setRasenganUntil(0);
            JutsuEffects.rasenganHit(player, target);
            com.shinobiarts.ninja.SharinganManager.updateLook(player);
            changed = true;
        }

        if (data.getActiveDojutsu() == Dojutsu.BYAKUGAN) {
            // Gentle Fist: strikes the chakra points directly.
            event.setAmount(event.getAmount() * 1.4f);
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
            Vec3 c = target.getBoundingBox().getCenter();
            Vec3 toward = player.getEyePosition().subtract(c).multiply(1, 0, 1);
            Vec3 hit = toward.lengthSqr() < 1e-4 ? c : c.add(toward.normalize().scale(target.getBbWidth() * 0.5 + 0.05));
            com.shinobiarts.fx.Fx.line(player.serverLevel(), com.shinobiarts.fx.Fx.Visual.GENTLE_FIST, hit, player.getEyePosition(), 1f, 8);
            if (target instanceof ServerPlayer victim) PlayerDataManager.drainChakra(victim, 15f);
        }
        if (com.shinobiarts.jutsu.AdvancedJutsu.boiling(player)) {      // Unrivalled Strength: every punch bursts with steam
            event.setAmount(event.getAmount() + com.shinobiarts.jutsu.AdvancedJutsu.steamPunch(player, target));
        }

        if (changed) ModNetwork.sync(player);
    }

    /** The Susanoo takes the hits meant for its owner (after dodges and Palm Rotation had their chance). */
    @SubscribeEvent(priority = net.minecraftforge.eventbus.api.EventPriority.LOW)
    public static void onAttackedSusanoo(LivingAttackEvent event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player)) return;
        if (com.shinobiarts.ninja.Susanoo.redirect(player, event.getSource(), event.getAmount())) event.setCanceled(true);
    }

    /** Nothing knocks you about inside a Susanoo. */
    @SubscribeEvent
    public static void onKnockBack(net.minecraftforge.event.entity.living.LivingKnockBackEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            NinjaData data = NinjaData.get(player);
            if (data != null && data.getSusanooStage() > 0) event.setCanceled(true);
        }
    }

    /** No fall damage right after a Ninja Jump, or inside a Susanoo. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        if (data.getSusanooStage() > 0) {
            event.setCanceled(true);
            return;
        }
        if (com.shinobiarts.ninja.ChakraControl.cushionsFall(player, data)) {
            event.setCanceled(true); // Chakra Control: landing on water, or sliding down a wall
            return;
        }
        if (data.getFallProtectUntil() > player.level().getGameTime()) {
            event.setDistance(Math.min(event.getDistance(), 3.0f));
        }
    }
}
