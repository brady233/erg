package com.shinobiarts.item;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * A blank scroll you can write on: right-click opens the writing screen (a title and as much as fits). What's written
 * is kept on the scroll, shown when you hover it, and readable again by right-clicking (and rewritable by its author).
 */
public class BlankScrollItem extends Item {
    public static final int MAX_TITLE = 32, MAX_TEXT = 1200;

    public BlankScrollItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(net.minecraftforge.api.distmarker.Dist.CLIENT,
                    () -> () -> com.shinobiarts.client.ClientHooks.openScrollWriting(hand, stack));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    public static void write(ItemStack stack, String title, String text, String author) {
        CompoundTag tag = stack.getOrCreateTag();
        String t = title == null ? "" : title.strip();
        String body = text == null ? "" : text.length() > MAX_TEXT ? text.substring(0, MAX_TEXT) : text;
        if (tag.contains("Author") && !tag.getString("Author").equals(author)) return;     // only its writer can change it
        tag.putString("Title", t.length() > MAX_TITLE ? t.substring(0, MAX_TITLE) : t);
        tag.putString("Text", body);
        tag.putString("Author", author);
        if (!t.isEmpty()) stack.setHoverName(Component.literal(t).withStyle(ChatFormatting.GOLD));
        else stack.resetHoverName();
    }

    public static String title(ItemStack stack) {
        return stack.hasTag() ? stack.getTag().getString("Title") : "";
    }

    public static String text(ItemStack stack) {
        return stack.hasTag() ? stack.getTag().getString("Text") : "";
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        String text = text(stack);
        if (text.isEmpty()) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.blank_scroll").withStyle(ChatFormatting.GRAY));
            return;
        }
        String[] lines = text.split("\n");
        for (int i = 0; i < Math.min(4, lines.length); i++) {
            String line = lines[i].length() > 40 ? lines[i].substring(0, 40) + "..." : lines[i];
            tooltip.add(Component.literal(line).withStyle(ChatFormatting.GRAY));
        }
        if (lines.length > 4) tooltip.add(Component.literal("...").withStyle(ChatFormatting.DARK_GRAY));
        if (stack.getTag().contains("Author")) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.scroll_author", stack.getTag().getString("Author")).withStyle(ChatFormatting.DARK_GRAY));
        }
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return !text(stack).isEmpty();
    }
}
