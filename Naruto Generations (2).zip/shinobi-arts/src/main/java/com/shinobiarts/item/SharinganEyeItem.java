package com.shinobiarts.item;

import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** A Sharingan eye taken from a defeated player. Right-click to implant it. */
public class SharinganEyeItem extends Item {
    public SharinganEyeItem(Properties properties) {
        super(properties);
    }

    public static ItemStack create(int stage, String from) {
        return create(stage, from, com.shinobiarts.ninja.MangekyouDesign.ITACHI);
    }

    /** A taken eye; a Mangekyou eye remembers its pattern (an Eternal one goes back to Itachi's). */
    public static ItemStack create(int stage, String from, com.shinobiarts.ninja.MangekyouDesign design) {
        ItemStack stack = new ItemStack(ModItems.SHARINGAN_EYE.get());
        CompoundTag tag = stack.getOrCreateTag();
        tag.putInt("Stage", stage);
        tag.putString("From", from);
        if (stage == Dojutsu.MANGEKYOU) {
            tag.putString("Design", (design == com.shinobiarts.ninja.MangekyouDesign.ETERNAL ? com.shinobiarts.ninja.MangekyouDesign.ITACHI : design).id());
        }
        return stack;
    }

    public static com.shinobiarts.ninja.MangekyouDesign design(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return com.shinobiarts.ninja.MangekyouDesign.byId(tag == null ? "" : tag.getString("Design"));
    }

    public static int stage(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag == null ? 1 : Math.max(1, Math.min(Dojutsu.MANGEKYOU, tag.getInt("Stage")));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer sp && SharinganManager.implant(sp, stage(stack), design(stack))) {
            String from = stack.hasTag() ? stack.getTag().getString("From") : "";
            if (!from.isEmpty() && !from.equals(sp.getGameProfile().getName())) {
                com.shinobiarts.ninja.NinjaData d = com.shinobiarts.ninja.NinjaData.get(sp);
                if (d != null) {
                    d.borrowedEyes = true;                            // someone else's eye: it'll cost them
                    sp.sendSystemMessage(Component.translatable("message.shinobiarts.eye_borrowed", from).withStyle(ChatFormatting.DARK_RED));
                }
            }
            if (!player.getAbilities().instabuild) stack.shrink(1);
            return InteractionResultHolder.consume(stack);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return stage(stack) == Dojutsu.MANGEKYOU;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Dojutsu.sharinganName(stage(stack), design(stack)));
        CompoundTag tag = stack.getTag();
        if (tag != null && !tag.getString("From").isEmpty()) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.eye_from", tag.getString("From")).withStyle(ChatFormatting.GRAY));
        }
        tooltip.add(Component.translatable("tooltip.shinobiarts.eye_implant").withStyle(ChatFormatting.YELLOW));
        com.shinobiarts.ninja.EyeTechniques.describe(stage(stack), design(stack), false, tooltip);
    }
}
